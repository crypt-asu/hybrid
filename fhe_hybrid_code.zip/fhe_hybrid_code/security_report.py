"""Prints the ACTUAL cryptographic parameters used by both libraries (for the paper's security statement)."""
import json, math, inspect, numpy as np
from concrete import fhe
from openfhe import *
from fhe_transcode.tfhe_ops import LutSpec, MaskedLut

print("=== CKKS (OpenFHE) ===")
p = CCParamsCKKSRNS(); p.SetMultiplicativeDepth(13); p.SetScalingModSize(41); p.SetFirstModSize(53)
p.SetRingDim(1 << 16); p.SetSecurityLevel(SecurityLevel.HEStd_128_classic)
p.SetScalingTechnique(ScalingTechnique.FLEXIBLEAUTO); p.SetBatchSize(1 << 12)
cc = GenCryptoContext(p)          # OpenFHE refuses to build the context if the HE-Standard 128-bit table is violated
print("ring dimension N        :", cc.GetRingDimension())
print("security level setting  :", p.GetSecurityLevel())
print("secret key distribution :", p.GetSecretKeyDist())
print("key switching technique :", p.GetKeySwitchTechnique())
print("ciphertext modulus log2Q: %.1f bits (first mod 53 + 13 x 41)" % math.log2(cc.GetModulus()))
print("HE-Standard max log2Q at N=2^16, 128-bit classic: 1772 bits (Q below it => >=128-bit security)")

print("\n=== TFHE (Concrete) ===")
sec = inspect.signature(fhe.Configuration.__init__).parameters["security_level"].default
print("Configuration.security_level default:", sec)
L = MaskedLut(LutSpec("exp", np.exp, -12.8, 0.0, B=8, out_scale=255.0, Bo=8, chunk=4))
info = L.circuit.server.client_specs.program_info
ks = json.loads(info.serialize())["keyset"]
for k in ks["lweSecretKeys"]:
    print("LWE secret key id %d: dimension %d, %s" % (k["id"], k["params"]["lweDimension"], k["params"]["keyType"]))
for b in ks["lweBootstrapKeys"]:
    q = b["params"]
    print("bootstrap key: glwe_dim %d x poly_size %d, decomposition %d levels x 2^%d, noise variance %.3e" %
          (q["glweDimension"], q["polynomialSize"], q["levelCount"], q["baseLog"], q["variance"]))
for k in ks["lweKeyswitchKeys"]:
    q = k["params"]
    print("keyswitch key: %d -> %d, %d levels x 2^%d, noise variance %.3e" %
          (q["inputLweDimension"], q["outputLweDimension"], q["levelCount"], q["baseLog"], q["variance"]))
print("(parameters chosen by Concrete's optimizer for security_level=%s and p_error=%.2e; modulus 2^64)" % (sec, L.circuit.p_error))
print("NOTE: not independently re-checked with the lattice estimator in this script.")
