"""C5 baseline (same machine, same CKKS parameter class): pure-CKKS Chebyshev polynomial approximation with OpenFHE's EvalChebyshevFunction.
No TFHE, no client interaction.  usage: python baseline_ckks_poly.py [--out FILE]
Reports precision = -log2 RMSE (absolute) over uniform samples, the time of one EvalChebyshevFunction on one ciphertext (all slots), and the multiplicative depth setting."""
import sys, os, json, time, math, platform, subprocess
import numpy as np
from scipy.special import erf
from openfhe import *
out = sys.argv[sys.argv.index("--out") + 1] if "--out" in sys.argv else "results_baseline_ckks_poly.jsonl"
def sh(c):
    try: return subprocess.run(c, shell=True, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception: return ""
HW = dict(cpu=sh("lscpu | grep 'Model name' | head -1 | cut -d: -f2").strip() or platform.processor(), cores=os.cpu_count(), gpu="none", python=platform.python_version())
DEPTH = {59: 6, 119: 7, 247: 8, 495: 9}      # OpenFHE's documented degree -> depth table for EvalChebyshev (checked below by running)
SLOTS = 4096
FN = {"GELU": (lambda x: 0.5 * x * (1 + erf(x / np.sqrt(2))), -20.0, 20.0),
      "SiLU": (lambda x: x / (1 + np.exp(-x)), -20.0, 20.0),
      "1/x": (lambda x: 1 / x, 0.01, 10.0),
      "1/sqrt(x)": (lambda x: 1 / np.sqrt(x), 0.01, 10.0)}
rng = np.random.default_rng(5)
for deg, depth in DEPTH.items():
    p = CCParamsCKKSRNS(); p.SetMultiplicativeDepth(depth + 1); p.SetScalingModSize(41); p.SetFirstModSize(53)
    p.SetRingDim(1 << 16); p.SetSecurityLevel(SecurityLevel.HEStd_128_classic); p.SetScalingTechnique(ScalingTechnique.FLEXIBLEAUTO); p.SetBatchSize(SLOTS)
    cc = GenCryptoContext(p)
    for f in (PKESchemeFeature.PKE, PKESchemeFeature.KEYSWITCH, PKESchemeFeature.LEVELEDSHE, PKESchemeFeature.ADVANCEDSHE): cc.Enable(f)
    kp = cc.KeyGen(); cc.EvalMultKeyGen(kp.secretKey)
    for name, (f, lo, hi) in FN.items():
        x = rng.uniform(lo, hi, SLOTS)
        ct = cc.Encrypt(kp.publicKey, cc.MakeCKKSPackedPlaintext(x.tolist()))
        t = time.time()
        try:
            r = cc.EvalChebyshevFunction(lambda v: float(f(v)), ct, lo, hi, deg)
            dt = time.time() - t
            pt = cc.Decrypt(r, kp.secretKey); pt.SetLength(SLOTS); y = np.array(pt.GetRealPackedValue()[:SLOTS])
            bits = float(-np.log2(np.sqrt(np.mean((y - f(x)) ** 2))))
            rec = dict(fn=name, range=[lo, hi], degree=deg, mult_depth_setting=depth + 1, slots=SLOTS, precision_bits=bits, time_one_ciphertext_s=dt, n_samples=SLOTS)
        except Exception as e:
            rec = dict(fn=name, range=[lo, hi], degree=deg, mult_depth_setting=depth + 1, error=str(e)[:200])
        rec["hardware"] = HW; rec["time"] = time.strftime("%Y-%m-%d %H:%M:%S"); rec["method"] = "OpenFHE EvalChebyshevFunction, pure CKKS"
        print(json.dumps(rec), flush=True); open(out, "a").write(json.dumps(rec) + "\n")
