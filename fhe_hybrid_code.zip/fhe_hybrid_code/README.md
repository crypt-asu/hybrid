# Kod ve ham sonuçlar: Client-Aided Hybrid FHE for Transformer Inference

Makaledeki (manuscript/main.tex) her sayısal sonuç, aşağıdaki betiklerin gerçek şifreli koşularından gelir.
Simülasyon, tahmin veya ekstrapolasyon sonucu yoktur. Donanım her kayıtta `hardware` alanında yazılıdır.

Makineler: A = Xeon 2.10 GHz, 2 çekirdek, 7 GB; B ve C = Xeon 2.20 GHz, 12 çekirdek (Concrete CPU'da çalıştı; C'de NVIDIA L4 vardı, `concrete_on_gpu: false`).

Ortam: Python 3.12, OpenFHE (openfhe-python 1.6.1.0.24.4), Concrete (concrete-python 2.11.0). Notebook `notebooks/Kisa_Deneyler_Colab.ipynb` tüm kurulumu ve Makine C koşularını içerir.

| Makaledeki sonuç | Betik | Ham sonuç dosyası |
|---|---|---|
| Tablo 9 (1/x, 1/sqrt x), Tablo 10 (GELU, SiLU), Tablo 6 (d=768), Makine A | `bench_rosetta.py table9/table10/table6` | `results/machineA_B/results.jsonl` |
| Softmax n=64 (Tablo 4) | `bench_rosetta.py table4 --n 64 --M 8` | `results_t4_n64.jsonl` |
| Softmax n=512, parçalı koşu (Tablo 4) | `bench_softmax_seg.py --n 512 --seg 64 --M 8` | `results_t4_seg.jsonl` |
| İndeks kayması (C2) | `a100/c2_index_check.py` | `results_c2.jsonl` |
| Çözücü hatası / hücre genişliği (C4) | `a100/c4_decoder_vs_cell.py` | `results_c4.jsonl` |
| Saf-CKKS taban (C5) | `baseline_ckks_poly.py`, `a100/c5_baseline_newton.py` | `results_baseline_ckks_poly.jsonl`, `results_c5.jsonl` |
| Mesaj ve anahtar boyutları | `comm_measure.py` | `results/machineA_B/comm.log` |
| TFHE stres testi (3/1440) | `stress.py`, `stress2.py` | (makalede özetlenmiş) |
| Tablo 6, d=2048 ve 4096 (Makine C) | `a100/c9_repeat_tables.py --table 6 --d ...` | `results/machineC_colab/c6_d2048.jsonl`, `c6_d4096.jsonl` |
| Sıfır olmayan ortalama, d=768 (C13) | `a100/c9_repeat_tables.py --table 6 --s2 150 --mean 2.0` | `c13_table6_mean2.jsonl` |
| Tekrarlı 1/x, GELU, SiLU (S=8, 3 tekrar) | `a100/c9_repeat_tables.py --table 9/10 --samples 8 --repeats 3` | `c9_table9.jsonl`, `c9_table10.jsonl` |
| Nihai devrelerde gerçek koşu (C1d) | `a100/c1_stress_final.py` | `c1_exp_soft.jsonl`, `c1_rsqrt_norm.jsonl` |
| Lattice estimator (C16) | `a100/c16_lattice_estimate.py` (`C16_FULL=1` tam mod) | `c16_rough.jsonl`, `c16_full.jsonl` |

Notlar
- `a100/c1_stress_final.py` içindeki `--simulate` seçeneği makaledeki hiçbir sonuçta kullanılmadı.
- `a100/c8_comm_opt.py` ve `a100/c6_softmax_repeat.py` makaledeki sonuçları üretmedi (C8: bu OpenFHE derlemesinde `LevelReduce` etkisiz; C6 softmax n>=1024: çalıştırılmadı).
- Estimator için `passagemath-standard` ve github.com/malb/lattice-estimator gerekir.
