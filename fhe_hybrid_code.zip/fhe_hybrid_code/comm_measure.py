"""Measures REAL serialized message sizes for one scalar rsqrt transcoding (d=768 RMSNorm configuration).
usage: python comm_measure.py"""
import os, sys, tempfile, time, numpy as np
from openfhe import SerializeToFile, BINARY, SerializeEvalMultKeyString, SerializeEvalAutomorphismKeyString
from fhe_transcode.ckks_layer import Ckks, transcode_nonlinear
from fhe_transcode.seglut import SegSpec, SegMaskedLut

def ser_len(v):
    return len(v.serialize())
def ckks_len(ct, d):
    f = os.path.join(d, "ct.bin"); SerializeToFile(f, ct, BINARY); return os.path.getsize(f)

spec = SegSpec("rsqrt_var", lambda x: 1.0/np.sqrt(x), 0.01, 150.0, 4, 10, 12, 15, True)
lut = SegMaskedLut(spec, chunk=1)
ck = Ckks(depth=12, slots=1024, sum_keys=True)
rng = np.random.default_rng(1)
tmp = tempfile.mkdtemp()
out = {}
# --- messages of ONE transcoding (scalar) -------------------------------------------------------------
ct_x = ck.enc(np.array([3.0]), tile_n=1)
out["ckks_fresh_ct_bytes"] = ckks_len(ct_x, tmp)
r_int = spec.draw_r(rng, 1)
ct_s = ck.add_plain(ct_x, r_int*spec.gunit - spec.lo, 1)
out["ckks_masked_ct_server_to_client_bytes"] = ckks_len(ct_s, tmp)
s_real = ck.dec(ct_s, 1)
from fhe_transcode.seglut import client_quantise_real
uc, us = client_quantise_real(spec, s_real)
enc_uc, enc_us = lut.client_encrypt(uc, us)
out["tfhe_client_to_server_bytes"] = sum(ser_len(v) for v in (enc_uc if isinstance(enc_uc,(list,tuple)) else [enc_uc])) + sum(ser_len(v) for v in (enc_us if isinstance(enc_us,(list,tuple)) else [enc_us]))
cc, cs = spec.server_consts(r_int)
r2 = rng.integers(0, 1<<spec.Bo, 1); rho = rng.integers(0, 2, 1)
res = lut.server_run(enc_uc, enc_us, cc, cs, r2, rho)
out["tfhe_server_to_client_bytes"] = sum(ser_len(v) for v in (res if isinstance(res,(list,tuple)) else [res]))
w, kp = lut.client_decrypt(res)
ct_w, ct_k = ck.enc(w.astype(float), 1), ck.enc(kp.astype(float), 1)
out["ckks_client_to_server_bytes"] = ckks_len(ct_w, tmp) + ckks_len(ct_k, tmp)
out["rounds_per_transcoding"] = 2
# --- one-time key material -----------------------------------------------------------------------------
out["tfhe_evaluation_keys_bytes"] = len(lut.eval_keys.serialize())
out["ckks_evalmult_key_bytes"] = len(SerializeEvalMultKeyString(BINARY, ck.kp.secretKey.GetKeyTag() if hasattr(ck.kp.secretKey,"GetKeyTag") else ""))
out["ckks_rotation_keys_bytes"] = len(SerializeEvalAutomorphismKeyString(BINARY, ck.kp.secretKey.GetKeyTag() if hasattr(ck.kp.secretKey,"GetKeyTag") else ""))
print("RESULT comm " + __import__("json").dumps(out))
