"""
Table 4 (softmax) in ROSETTA's setting, executed in resumable segments because one process cannot run the whole TFHE exp stage
inside the 2-hour limit of the 2-core Sandbox.  NOTHING in ckks_layer.py / softmax.py / bench_rosetta.py is changed; this file only
re-orders the same protocol steps (copied from transcode_taylor and PrivateSoftmax):

  segment phase   (per process): CKKS mask + client decryption + quantisation for all n elements (cheap), then the TFHE exp circuit for
                  the requested segments of `seg` elements; the client-decrypted masked words of each segment are saved to disk.
  final phase     : load all segments, re-encrypt the words in CKKS, unmask, finish exp, then the k normalise-and-square rounds
                  (EvalSum, TFHE reciprocal of the scalar sum + Newton, EvalMult), decrypt, compare with the float softmax.

All random values of the exp stage come from one seeded generator drawn in the same order as in the single-process code, so every
process reproduces the same masks (r_int, wide offset, r2, rho).  Fresh CKKS keys are generated in each process, so the quantised
index vector u recomputed in the final process may differ from the stored one only for elements whose decrypted value lies within the
CKKS decryption noise of a quantisation boundary; the number of such elements is measured and reported.
The reported latency is the SUM of measured stage times; it is not one continuous wall-clock run.
"""
import sys, os, json, time, math, platform, subprocess, argparse
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fhe_transcode import oracle
from fhe_transcode.ckks_layer import Ckks, transcode_nonlinear, newton_inv
from fhe_transcode.seglut import SegSpec, SegMaskedLut
from fhe_transcode.taylor import TaylorSpec, TaylorMaskedLut

ap = argparse.ArgumentParser()
ap.add_argument("--n", type=int, default=512); ap.add_argument("--M", type=int, default=8); ap.add_argument("--seg", type=int, default=64)
ap.add_argument("--segs", default=""); ap.add_argument("--final", action="store_true"); ap.add_argument("--work", default="seg_n512_M8")
ap.add_argument("--out", default="results_t4_seg.jsonl")
args = ap.parse_args()
n, M, seg = args.n, args.M, args.seg
assert n % seg == 0
nseg = n // seg
k = int(round(math.log2(M))); assert 2 ** k == M
os.makedirs(args.work, exist_ok=True)

def sh(c):
    try: return subprocess.run(c, shell=True, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception: return ""
HW = dict(cpu=sh("lscpu | grep 'Model name' | head -1 | cut -d: -f2").strip() or platform.processor(), cores=os.cpu_count(),
          gpu=sh("nvidia-smi --query-gpu=name --format=csv,noheader") or "none", concrete_on_gpu=False, python=platform.python_version())
bits = lambda e: float(-np.log2(np.sqrt(np.mean(np.square(e)))))

# ---- same configuration as bench_rosetta.py table4 -----------------------------------------------------------------------------
base = 4 * k + 2
assert base <= 29
n_newton = min(k, 1 + (29 - base) // 2)
sched = [1] * n_newton + [0] * (k - n_newton)
depth = base + 2 * (n_newton - 1)
f_exp = lambda z: np.exp(z / 2 ** k)
sp = TaylorSpec("exp_k", f_exp, None, -float(M), float(M), 9, 15, 1, slope_ratio=1.0 / 2 ** k)
word_bits = [b for (_, _, b) in sp.words()]
nw = len(word_bits)

ck = Ckks(depth=depth, slots=max(16, 1 << math.ceil(math.log2(n))), sum_keys=args.final)
rng = np.random.default_rng(3)
z = np.clip(rng.normal(0, M / math.sqrt(3), n), -M, M)
ref = np.exp(z - z.max()); ref /= ref.sum()
ct_z = ck.enc(z)

# ---- exp stage, server side: one-time pad (identical call order to transcode_taylor) ------------------------------------------
t0 = time.time()
r_int = sp.draw_r(rng, n)
ct_s = ck.add_plain(ct_z, r_int * sp.gunit + ck.wide_offset(rng, n, sp.D, ct_z) - sp.lo, None)
c = sp.server_consts(r_int)
r2 = np.stack([rng.integers(0, 1 << b, n) for b in word_bits]); rho = rng.integers(0, 2, (nw, n))
u = sp.client_quantise(ck.dec(ct_s, n))
t_mask = time.time() - t0
print(f"mask+decrypt+quantise for {n} elements: {t_mask:.1f}s", flush=True)

segfile = lambda s: os.path.join(args.work, f"seg_{s}.npz")

# ---- segment phase ------------------------------------------------------------------------------------------------------------
todo = [int(x) for x in args.segs.split(",") if x != "" and not os.path.exists(segfile(int(x)))]
if todo:
    lut = TaylorMaskedLut(sp, chunk=seg, p_error=1e-10)
    print(f"TFHE exp circuit chunk={seg}: compile {lut.t_compile:.1f}s keygen {lut.t_keygen:.1f}s, PBS per chunk "
          f"{int(lut.circuit.programmable_bootstrap_count)}, p_error {lut.circuit.p_error:.3g}", flush=True)
    for s in todo:
        sl = slice(s * seg, (s + 1) * seg)
        t = time.time()
        enc_u = lut.client_encrypt(u[sl])
        res = lut.server_run(enc_u, c[sl], r2[:, sl], rho[:, sl])
        words = lut.client_decrypt(res)
        dt = time.time() - t
        oracle.reset(); oracle.check_taylor(sp, u[sl], c[sl], r2[:, sl], rho[:, sl], words); snap = oracle.snapshot(); oracle.reset()
        np.savez(segfile(s) + ".tmp.npz", u=u[sl], dt=dt, bad=snap["bad"], elems=snap["elements"],
                 **{f"w{j}": words[j][0] for j in range(nw)}, **{f"k{j}": words[j][1] for j in range(nw)})
        os.replace(segfile(s) + ".tmp.npz", segfile(s))
        print(f"segment {s}/{nseg} done: TFHE exp {dt:.1f}s, oracle bad {snap['bad']}/{snap['elements']}", flush=True)

# ---- final phase --------------------------------------------------------------------------------------------------------------
if args.final:
    missing = [s for s in range(nseg) if not os.path.exists(segfile(s))]
    if missing:
        print("missing segments:", missing, flush=True); sys.exit(2)
    D = [np.load(segfile(s)) for s in range(nseg)]
    u_stored = np.concatenate([d["u"] for d in D])
    u_mismatch = int(np.sum(u_stored != u))
    t_tfhe = float(sum(float(d["dt"]) for d in D))
    bad = int(sum(int(d["bad"]) for d in D)); elems = int(sum(int(d["elems"]) for d in D))
    words = [(np.concatenate([d[f"w{j}"] for d in D]).astype(np.int64), np.concatenate([d[f"k{j}"] for d in D]).astype(np.int64)) for j in range(nw)]
    tf = time.time()
    # ---- exp stage, CKKS side (copied from transcode_taylor) ----
    enc = [(ck.enc(w.astype(float), None), ck.enc(kk.astype(float), None)) for (w, kk) in words]
    lab = [l for (l, _, _) in sp.words()]
    def part(j, alpha, const):
        b = word_bits[j]
        ctw, ctk = enc[j]
        t1 = ck.mul_plain(ctw, np.full(n, alpha), None)
        t2 = ck.mul_plain(ctk, alpha * (1 << b) * (1 - 2 * rho[j]), None)
        return ck.add_plain(ck.add(t1, t2), alpha * ((1 << b) * rho[j] - r2[j]) + const, None)
    if sp.Bh:
        T = ck.add(part(lab.index("Thi"), (1 << sp.Bl) / sp.Tsc, sp.Tlo), part(lab.index("Tlo"), 1.0 / sp.Tsc, 0.0))
    else:
        T = part(lab.index("T"), 1.0 / sp.Tsc, sp.Tlo)
    x0 = part(lab.index("R"), sp.step, sp.lo)
    delta = ck.cc.EvalSub(ct_z, x0)
    assert sp.slope_ratio is not None
    fac = ck.add_plain(ck.mul_plain(delta, np.full(n, sp.slope_ratio), None), np.full(n, 1.0), None)
    y = ck.cc.EvalMult(T, fac)
    t_exp_ckks = time.time() - tf
    print(f"exp stage CKKS unmask+combine: {t_exp_ckks:.1f}s", flush=True)
    # ---- k normalise-and-square rounds (copied from PrivateSoftmax.__call__) ----
    rec = dict(nseg=4, Bp=10, Bc=12, Bo=15)
    inv = lambda x: 1.0 / x
    rec1 = SegSpec("1/s_round1", inv, n * math.exp(-2), n * math.exp(2), rec["nseg"], rec["Bp"], rec["Bc"], rec["Bo"], True)
    recn = SegSpec("1/s_roundN", inv, 1.0 / n, 1.0, rec["nseg"], rec["Bp"], rec["Bc"], rec["Bo"], True)
    rec1_lut = SegMaskedLut(rec1, chunk=1, p_error=1e-10); recn_lut = SegMaskedLut(recn, chunk=1, p_error=1e-10)
    stage = [f"exp over {n} elements, TFHE (sum of {nseg} segments): {t_tfhe:.1f}s", f"exp over {n} elements, CKKS unmask+combine: {t_exp_ckks:.1f}s"]
    t_rounds = 0.0
    for j in range(k):
        y2 = ck.cc.EvalMult(y, y)
        s_ct = ck.cc.EvalSum(y2, ck.slots)
        spec_, lut_ = (rec1, rec1_lut) if j == 0 else (recn, recn_lut)
        t = time.time()
        r0, _ = transcode_nonlinear(ck, lut_, spec_, s_ct, 1, rng, tile_n=1)
        r = newton_inv(ck, s_ct, r0, sched[j]) if sched[j] else r0
        dtj = time.time() - t; t_rounds += dtj
        stage.append(f"round {j+1}/{k}: reciprocal of the sum (TFHE+Newton): {dtj:.1f}s")
        print(stage[-1], flush=True)
        y = ck.cc.EvalMult(y2, r)
    out = ck.dec(y, n)
    rec_out = dict(table="4", n=n, M=M, k=k, ckks_depth=depth, exp_mode="taylor1(B=9,Bt=15)", newton_schedule=sched,
                   precision_bits=bits(out - ref), sum_of_outputs=float(out.sum()),
                   latency_s=t_tfhe + t_exp_ckks + t_rounds + t_mask, latency_note="sum of measured stage times; TFHE exp stage run in segments over several processes (not one wall-clock run)",
                   segmented=dict(seg=seg, nseg=nseg, u_mismatch_vs_stored=u_mismatch, mask_decrypt_quantise_s=t_mask),
                   stage_log=stage, tfhe_oracle=dict(elements=elems, bad=bad), hardware=HW, time=time.strftime("%Y-%m-%d %H:%M:%S"))
    print("RESULT", json.dumps(rec_out), flush=True)
    open(args.out, "a").write(json.dumps(rec_out) + "\n")
