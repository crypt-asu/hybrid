"""
CKKS side (OpenFHE) of the client-aided transcoding:  N = 2^16, depth 13, 41-bit scaling, 128-bit security
(the ROSETTA CKKS parameter class).  No bootstrapping: every nonlinear step re-encrypts fresh ciphertexts.
"""
from __future__ import annotations
from . import oracle
import time
import numpy as np
from openfhe import *


class Ckks:
    LAMBDA = 24      # statistical masking parameter of the wide input mask (see wide_offset)

    def __init__(self, depth=13, ring=1 << 16, slots=1 << 12, rot_indices=(), sum_keys=False, spare=1):
        # `depth` is the multiplicative depth the computation uses; `spare` extra level(s) are reserved so that the wide-masked
        # ciphertext can still be decrypted: its plaintext |s|*2^41 must stay below the remaining modulus (see wide_offset).
        p = CCParamsCKKSRNS()
        p.SetMultiplicativeDepth(depth + spare); p.SetScalingModSize(41); p.SetFirstModSize(53)
        p.SetRingDim(ring); p.SetSecurityLevel(SecurityLevel.HEStd_128_classic)
        p.SetScalingTechnique(ScalingTechnique.FLEXIBLEAUTO); p.SetBatchSize(slots)
        t = time.time()
        self.cc = GenCryptoContext(p)
        for f in (PKESchemeFeature.PKE, PKESchemeFeature.KEYSWITCH, PKESchemeFeature.LEVELEDSHE, PKESchemeFeature.ADVANCEDSHE):
            self.cc.Enable(f)
        self.kp = self.cc.KeyGen()
        self.cc.EvalMultKeyGen(self.kp.secretKey)
        if sum_keys:
            self.cc.EvalSumKeyGen(self.kp.secretKey)
        if len(rot_indices):
            self.cc.EvalAtIndexKeyGen(self.kp.secretKey, list(rot_indices))
        self.slots = slots
        self.depth = depth; self.L = depth + spare
        self.t_setup = time.time() - t

    def _pad(self, v):
        a = np.zeros(self.slots); a[:len(v)] = np.asarray(v, float); return a.tolist()

    def pt(self, v, tile_n=None):
        if tile_n: return self.cc.MakeCKKSPackedPlaintext(self.tile(v, tile_n).tolist())
        return self.cc.MakeCKKSPackedPlaintext(self._pad(v))

    def enc(self, v, tile_n=None):          # (client encrypts under the CKKS public key)
        if tile_n: return self.cc.Encrypt(self.kp.publicKey, self.cc.MakeCKKSPackedPlaintext(self.tile(v, tile_n).tolist()))
        return self.cc.Encrypt(self.kp.publicKey, self.pt(v))

    def dec(self, ct, n):                   # (client decrypts)
        p = self.cc.Decrypt(ct, self.kp.secretKey); p.SetLength(n)
        return np.array(p.GetRealPackedValue()[:n])

    def wide_offset(self, rng, n, M, ct=None):
        """Statistically hiding part of the input mask:  M * j  with j uniform on [0, 2^LAMBDA).  It is a multiple of the TFHE
        modulus M, so the client's reduction (s mod M) is unchanged, while the unreduced value the client decrypts is
        z + r_low + M*j and its distribution depends on z only through a shift of at most D out of a range of M*2^LAMBDA.
        The decrypted magnitude needs headroom: >= 2 RNS limbs must remain (53+41 bits) at the masking point."""
        if ct is not None:
            limbs = self.L + 1 - ct.GetLevel()
            assert limbs >= 2, f"wide mask needs >=2 limbs, ciphertext has {limbs}"
        return M * rng.integers(0, 1 << self.LAMBDA, n).astype(float)

    # --- linear algebra on ciphertexts (server) ---
    def add_plain(self, ct, v, tile_n=None): return self.cc.EvalAdd(ct, self.pt(v, tile_n))
    def mul_plain(self, ct, v, tile_n=None): return self.cc.EvalMult(ct, self.pt(v, tile_n))
    def add(self, a, b): return self.cc.EvalAdd(a, b)

    @staticmethod
    def bsgs_indices(n):
        g = int(np.ceil(np.sqrt(n))); G = int(np.ceil(n / g))
        return sorted(set(list(range(1, g)) + [j * g for j in range(1, G)])), g, G

    def matvec(self, W, ct, n):
        """y = W x (n x n) with x tiled periodically (period n) in the slots; baby-step/giant-step diagonal method.
        Needs rotation keys for bsgs_indices(n). One plaintext multiplication level."""
        idx, g, G = self.bsgs_indices(n)
        baby = [ct] + [self.cc.EvalRotate(ct, i) for i in range(1, g)]
        out = None
        for j in range(G):
            inner = None
            for i in range(g):
                d = j * g + i
                if d >= n: break
                diag = np.array([W[r, (r + d) % n] for r in range(n)])
                diag_t = np.roll(np.tile(diag, self.slots // n), j * g)       # pre-rotate by -j*g
                term = self.cc.EvalMult(baby[i], self.pt(diag_t))
                inner = term if inner is None else self.cc.EvalAdd(inner, term)
            if j: inner = self.cc.EvalRotate(inner, j * g)
            out = inner if out is None else self.cc.EvalAdd(out, inner)
        return out

    def tile(self, v, n):
        return np.tile(np.asarray(v, float), self.slots // n)


def transcode_nonlinear(ck: Ckks, lut, spec, ct_x, n, rng, tile_n=None):
    """CKKS ct of x  ->  CKKS ct of f(x) through TFHE. Returns (ct_y, info). Roles are separated in the code:
       SERVER: mask, TFHE evaluation, unmask.   CLIENT: decrypt, quantise, TFHE-encrypt/decrypt, CKKS-encrypt."""
    from .seglut import client_quantise_real
    # ---------------- SERVER: one-time-pad in the real domain -------------------------------
    r_int = spec.draw_r(rng, n)
    r_real = r_int * spec.gunit + ck.wide_offset(rng, n, spec.M, ct_x)    # r = r_low + M*j  (j uniform, 2^LAMBDA values)
    ct_s = ck.add_plain(ct_x, r_real - spec.lo, tile_n)           # s = (x - lo) + r        (mod M done by the client)
    r2 = rng.integers(0, 1 << spec.Bo, n); rho = rng.integers(0, 2, n)
    cc, cs = spec.server_consts(r_int)
    # ---------------- CLIENT ----------------------------------------------------------------
    s_real = ck.dec(ct_s, n)                               # the client decrypts s = (x-lo)+r_low+M*j over the reals; j is uniform on 2^LAMBDA values, so the views of z and z' are within statistical distance |z-z'|/(M*2^LAMBDA)
    uc, us = client_quantise_real(spec, s_real)
    enc_uc, enc_us = lut.client_encrypt(uc, us)            # under the client's TFHE key
    # ---------------- SERVER: TFHE evaluation on ciphertexts ------------------------------------
    res = lut.server_run(enc_uc, enc_us, cc, cs, r2, rho)
    # ---------------- CLIENT: decrypt masked result, re-encrypt under CKKS -------------------------
    w, kp = lut.client_decrypt(res)
    oracle.check_seg(spec, uc, us, cc, cs, r2, rho, w, kp)    # measurement only: compares with the exact integer circuit
    ct_w, ct_k = ck.enc(w.astype(float), tile_n), ck.enc(kp.astype(float), tile_n)
    # ---------------- SERVER (CKKS, linear): remove the output mask ----------------------------------
    sc = spec.scale
    ct1 = ck.mul_plain(ct_w, np.full(n, 1.0 / sc), tile_n)
    ct1 = ck.add_plain(ct1, (((1 << spec.Bo) * rho - r2) / sc) + spec.ylo, tile_n)
    ct2 = ck.mul_plain(ct_k, ((1 << spec.Bo) * (1 - 2 * rho)) / sc, tile_n)
    return ck.add(ct1, ct2), dict(s_real=s_real, uc=uc, us=us, cc=cc, cs=cs, r_int=r_int)


def newton_inv(ck: Ckks, ct_x, ct_y, iters=1):
    """CKKS-side refinement of y ~ 1/x:  y <- y (2 - x y).  2 multiplicative levels per iteration, no PBS.
    (negation and addition of a constant do not consume a level; a constant multiplication would)"""
    cc = ck.cc
    for _ in range(iters):
        t = cc.EvalMult(ct_x, ct_y)                         # x*y
        u = cc.EvalAdd(cc.EvalNegate(t), 2.0)               # 2 - x*y
        ct_y = cc.EvalMult(ct_y, u)
    return ct_y


def newton_rsqrt(ck: Ckks, ct_x, ct_y, iters=1):
    """y ~ x^(-1/2):  y <- 1.5 y - 0.5 x y^3 = 1.5 y - (x y^2)(y/2).   3 levels per iteration, no PBS.
    The half is applied to y in parallel with the x*y*y chain so it adds no depth."""
    cc = ck.cc
    for _ in range(iters):
        yh = cc.EvalMult(ct_y, 0.5)                         # y/2
        t = cc.EvalMult(cc.EvalMult(ct_x, ct_y), ct_y)      # x y^2
        ct_y = cc.EvalSub(cc.EvalMult(ct_y, 1.5), cc.EvalMult(t, yh))
    return ct_y



def transcode_lut(ck: Ckks, lut, ct_x, n, rng, tile_n=None, G=40):
    """Same protocol as transcode_nonlinear but for the single-table MaskedLut (smooth bounded functions: exp, GELU, SiLU).
    Grid: B bits over [lo, hi); modulus of the one-time pad = hi - lo = 2^B * step (cyclic group, perfect hiding)."""
    sp = lut.spec
    B, Bo, N = sp.B, sp.Bo, 1 << sp.B
    D = sp.hi - sp.lo
    # ---------------- SERVER: one-time-pad in the real domain ----------------------------------
    r_int = rng.integers(0, 2 ** G, n, dtype=np.int64)
    r_real = r_int * (D / 2.0 ** G)
    ct_s = ck.add_plain(ct_x, r_real - sp.lo, tile_n)               # s = (x - lo) + r  (mod D by the client)
    rq = r_int >> (G - B)
    c = N - rq
    r2 = rng.integers(0, 1 << Bo, n); rho = rng.integers(0, 2, n)
    # ---------------- CLIENT -----------------------------------------------------------------
    s_real = np.mod(ck.dec(ct_s, n), D)
    u = np.floor(s_real / sp.step).astype(np.int64) % N
    enc_u = lut.client_encrypt(u)
    # ---------------- SERVER: TFHE ---------------------------------------------------------------
    res = lut.server_run(enc_u, c, r2, rho)
    # ---------------- CLIENT: decrypt masked output, re-encrypt in CKKS --------------------------------
    w, kp = lut.client_decrypt(res)
    ct_w, ct_k = ck.enc(w.astype(float), tile_n), ck.enc(kp.astype(float), tile_n)
    # ---------------- SERVER (CKKS, linear): remove the output mask ---------------------------------------
    sc = sp.out_scale
    ct1 = ck.mul_plain(ct_w, np.full(n, 1.0 / sc), tile_n)
    ct1 = ck.add_plain(ct1, (((1 << Bo) * rho - r2) / sc) + sp.out_lo, tile_n)
    ct2 = ck.mul_plain(ct_k, ((1 << Bo) * (1 - 2 * rho)) / sc, tile_n)
    return ck.add(ct1, ct2), dict(u=u, c=c, r2=r2, rho=rho)


def transcode_taylor(ck: Ckks, lut, ct_x, n, rng, tile_n=None):
    """CKKS ct of x -> CKKS ct of f(x) with first-order correction.  TFHE returns masked words (T digits, slope A, cell index R);
    the server removes the masks linearly in CKKS and finishes  y = T + A*(x - x0)  with ONE ct*ct multiplication."""
    sp = lut.spec
    # ---------------- SERVER: one-time-pad ----------------------------------------------------
    r_int = sp.draw_r(rng, n)
    ct_s = ck.add_plain(ct_x, r_int * sp.gunit + ck.wide_offset(rng, n, sp.D, ct_x) - sp.lo, tile_n)
    c = sp.server_consts(r_int)
    r2 = np.stack([rng.integers(0, 1 << b, n) for b in lut.bits]); rho = rng.integers(0, 2, (lut.nw, n))
    # ---------------- CLIENT ---------------------------------------------------------------------
    u = sp.client_quantise(ck.dec(ct_s, n))
    enc_u = lut.client_encrypt(u)
    # ---------------- SERVER: TFHE ------------------------------------------------------------------
    res = lut.server_run(enc_u, c, r2, rho)
    # ---------------- CLIENT: decrypt masked words, re-encrypt in CKKS -------------------------------------
    words = lut.client_decrypt(res)
    oracle.check_taylor(sp, u, c, r2, rho, words)             # measurement only
    enc = [(ck.enc(w.astype(float), tile_n), ck.enc(k.astype(float), tile_n)) for (w, k) in words]
    # ---------------- SERVER (CKKS): unmask + combine (all linear, folded into one plaintext multiply per word) --
    lab = [l for (l, _, _) in sp.words()]
    def part(j, alpha, const):
        b = lut.bits[j]
        ctw, ctk = enc[j]
        t1 = ck.mul_plain(ctw, np.full(n, alpha), tile_n)
        t2 = ck.mul_plain(ctk, alpha * (1 << b) * (1 - 2 * rho[j]), tile_n)
        t3 = ck.add_plain(ck.add(t1, t2), alpha * ((1 << b) * rho[j] - r2[j]) + const, tile_n)
        return t3
    if sp.Bh:
        iT = lab.index("Thi"); jT = lab.index("Tlo")
        T = ck.add(part(iT, (1 << sp.Bl) / sp.Tsc, sp.Tlo), part(jT, 1.0 / sp.Tsc, 0.0))
    else:
        T = part(lab.index("T"), 1.0 / sp.Tsc, sp.Tlo)
    x0 = part(lab.index("R"), sp.step, sp.lo)
    delta = ck.cc.EvalSub(ct_x, x0)
    if sp.slope_ratio is not None:                        # y = T * (1 + ratio*(x - x0))   (f' = ratio * f)
        fac = ck.add_plain(ck.mul_plain(delta, np.full(n, sp.slope_ratio), tile_n), np.full(n, 1.0), tile_n)
        y = ck.cc.EvalMult(T, fac)
    else:
        A = part(lab.index("A"), 1.0 / sp.Asc, sp.Alo)
        y = ck.add(T, ck.cc.EvalMult(A, delta))
    return y, dict(u=u, c=c, r_int=r_int)
