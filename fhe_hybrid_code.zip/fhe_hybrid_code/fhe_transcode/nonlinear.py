"""Nonlinear functions as masked TFHE LUTs, with ROSETTA's evaluation ranges.
Precision here is the exact integer-domain result (identical to what the FHE LUT returns when it is exact)."""
import numpy as np
from .tfhe_ops import LutSpec

gelu = lambda x: 0.5*x*(1+np.vectorize(__import__('math').erf)(x/np.sqrt(2)))
silu = lambda x: x/(1+np.exp(-x))

def exp_spec(R, B, Bo):      # softmax numerator after max-subtraction: x in [-2R? ...]; inputs x-max in [-2R,0]
    return LutSpec(f"exp[-{2*R},0]", np.exp, -2.0*R, 0.0, B, float(2**Bo-1), Bo)
def gelu_spec(B, Bo, lo=-20., hi=20.):
    ylo, yhi = float(gelu(np.linspace(lo,hi,100001)).min()), float(hi)
    return LutSpec("gelu", gelu, lo, hi, B, (2**Bo-1)/(yhi-ylo), Bo, out_lo=ylo)
def silu_spec(B, Bo, lo=-20., hi=20.):
    ylo = float(silu(np.linspace(lo,hi,100001)).min())
    return LutSpec("silu", silu, lo, hi, B, (2**Bo-1)/(hi-ylo), Bo, out_lo=ylo)
def recip_spec(B, Bo, lo, hi):
    return LutSpec(f"1/x[{lo},{hi}]", lambda x: 1.0/x, lo, hi, B, (2**Bo-1)/(1.0/lo), Bo)
def rsqrt_spec(B, Bo, lo, hi):
    return LutSpec(f"rsqrt[{lo},{hi}]", lambda x: 1.0/np.sqrt(x), lo, hi, B, (2**Bo-1)/(1.0/np.sqrt(lo)), Bo)

def precision(spec, n=200000, seed=0, lo=None, hi=None):
    """returns (-log2 RMSE_abs, -log2 RMSE_rel) of the quantised LUT vs exact float f on random inputs."""
    rng = np.random.default_rng(seed)
    lo = spec.lo if lo is None else lo; hi = spec.hi if hi is None else hi
    x = rng.uniform(lo, hi, n)
    y = spec.dequant_out(spec.plain(x)); t = spec.fn(x)
    e = y - t
    ra = np.sqrt(np.mean(e**2)); rr = np.sqrt(np.mean((e/t)**2))
    return -np.log2(ra), -np.log2(rr)
