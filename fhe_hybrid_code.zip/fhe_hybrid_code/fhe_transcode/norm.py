"""
Private RMSNorm / LayerNorm.  Linear parts (sums, squares, scaling) in CKKS, the inverse square root of the scalar
variance in TFHE through client-aided transcoding, refined by a CKKS Newton step.
    RMSNorm  : y = gamma * x * rsqrt(mean(x^2) + eps)
    LayerNorm: y = gamma * (x - mu) * rsqrt(mean(x^2) - mu^2 + eps) + beta
Variance range handled by the segmented table: [lo, sigma2_max]  (inputs outside are clipped by the quantiser: documented limit).
Slots are padded with zeros up to the next power of two; sums use E[x^2] (padding-safe), not centred squares.
"""
from __future__ import annotations
import math, time
import numpy as np
from .seglut import SegSpec, SegMaskedLut
from .ckks_layer import Ckks, transcode_nonlinear, newton_rsqrt


class PrivateNorm:
    def __init__(self, d, kind, sigma2_max, lo=0.01, eps=1e-5, rec=dict(nseg=4, Bp=10, Bc=12, Bo=15), use_gpu=False, p_error=1e-10):
        assert kind in ("rms", "layer")
        self.d, self.kind, self.eps = d, kind, eps
        self.slots = 1 << max(4, math.ceil(math.log2(d)))
        self.spec = SegSpec("rsqrt_var", lambda x: 1.0 / np.sqrt(x), lo, float(sigma2_max), rec["nseg"], rec["Bp"], rec["Bc"], rec["Bo"], True)
        self.lut = SegMaskedLut(self.spec, chunk=1, use_gpu=use_gpu, p_error=p_error)

    def __call__(self, ck: Ckks, ct_x, gamma, beta, rng, newton_iters=1, log=None):
        d, cc = self.d, ck.cc
        t = time.time()
        x2 = cc.EvalMult(ct_x, ct_x)
        ex2 = ck.mul_plain(cc.EvalSum(x2, ck.slots), np.full(ck.slots, 1.0 / d))          # E[x^2] in every slot
        if self.kind == "layer":
            mu = ck.mul_plain(cc.EvalSum(ct_x, ck.slots), np.full(ck.slots, 1.0 / d))     # mean in every slot
            var = cc.EvalSub(ex2, cc.EvalMult(mu, mu))
            xc = cc.EvalSub(ct_x, mu)
        else:
            var, xc = ex2, ct_x
        var = ck.add_plain(var, np.full(ck.slots, self.eps))
        if log: log(f"  CKKS statistics: {time.time()-t:.2f}s")
        t = time.time()
        r0, _ = transcode_nonlinear(ck, self.lut, self.spec, var, 1, rng, tile_n=1)     # r0 = 1/sqrt(var) (table), replicated
        r = newton_rsqrt(ck, var, r0, newton_iters)
        if log: log(f"  rsqrt of the variance (TFHE transcoding + Newton): {time.time()-t:.1f}s")
        t = time.time()
        y = cc.EvalMult(ck.mul_plain(xc, gamma), r)
        if beta is not None:
            y = ck.add_plain(y, beta)
        if log: log(f"  CKKS scaling: {time.time()-t:.2f}s")
        return y, var
