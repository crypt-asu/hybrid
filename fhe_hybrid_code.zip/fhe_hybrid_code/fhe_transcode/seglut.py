"""
Segmented masked LUT (client-aided transcoding) for wide-range functions: 1/x, 1/sqrt(x), exp, GELU, SiLU.

Protocol for one element x in [lo, hi]  (z = x - lo in [0, D]):
  Server (CKKS) holds Enc(z).  It draws r uniform on the cyclic group Z_M (M = 2^e, M > D + margins) and sends
  Enc(z + r) to the client.  The client decrypts s = (z + r) mod M and only ever sees this uniform value.
  The client quantises s on several grids and encrypts under ITS OWN TFHE key:
      u_c  = floor(s / Delta_c)                      mod 2^Bc      (coarse grid, selects the segment)
      u_i  = floor(s / Delta_i)                      mod 2^Bp      (fine grid of segment i)
  Server (TFHE, clear-text constants derived from r; never sent to the client):
      v_c  = u_c + c_c                    ->  sel_i = SEL_i[v_c]                 (one-hot segment indicator)
      idx_i = (u_i + c_i) + 2^(Bp+1) sel_i  ->  y_i = TAB_i[idx_i]               (= T_i[res_i] if selected, else 0)
      y1   = sum_i y_i ; s2 = y1 + r2 ; w = s2 mod 2^Bo ; k' = carry(s2) xor rho   (output one-time-pad)
  Server -> client (w, k'); client re-encrypts under CKKS; the server removes the mask linearly.
Everything is exact integer arithmetic; the only approximation is the quantisation + table (measured by `precision`).
All real quantities are held as integers in units g = M / 2^G (G = 40) so that client and server agree bit-exactly.
"""
from __future__ import annotations
import math, time
from dataclasses import dataclass, field
import numpy as np


@dataclass
class SegSpec:
    name: str
    fn: callable
    lo: float
    hi: float
    nseg: int
    Bp: int                 # fine bits per segment
    Bc: int                 # coarse bits (segment selection)
    Bo: int                 # output bits
    log: bool = True        # log-spaced boundaries (1/x, 1/sqrt x) or uniform (GELU/SiLU/exp)
    margin_cells: int = 2   # window margin in coarse cells
    G: int = 40

    def __post_init__(self):
        assert self.Bp + 2 <= 16 and self.Bc + 1 <= 16 and self.Bo + 1 <= 16
        D = self.hi - self.lo
        self.D = D
        self.dc_min = None
        # M: power of two with room for D plus one coarse cell and the margins
        e = math.ceil(math.log2(D * (1 + (2 + 2 * self.margin_cells) / 2 ** self.Bc)))
        self.M = 2.0 ** e
        self.Dc = self.M / 2 ** self.Bc
        m = self.margin_cells * self.Dc
        tau = (np.geomspace(self.lo, self.hi, self.nseg + 1) if self.log
               else np.linspace(self.lo, self.hi, self.nseg + 1))
        self.tau = tau
        self.b = tau - self.lo                                  # boundaries in z units
        self.F, self.A, self.L = [], [], []
        for i in range(self.nseg):
            W = (self.b[i + 1] - self.b[i]) + 2 * m
            F = self.Bp + int(math.floor(math.log2(self.M / W)))
            assert self.Bp <= F <= self.G, (self.name, i, F)
            self.F.append(F)
            self.A.append(self.b[i] - m)
            self.L.append(self.M * 2.0 ** (self.Bp - F))
        # output scaling
        g = np.concatenate([np.linspace(tau[i], tau[i + 1], 4001) for i in range(self.nseg)])
        v = self.fn(g)
        self.ylo, yhi = float(v.min()), float(v.max())
        self.scale = (2 ** self.Bo - 1) / (yhi - self.ylo)
        # tables
        nv = 2 ** (self.Bc + 1)
        zc = (np.arange(nv) % 2 ** self.Bc) * self.Dc
        self.SEL = []
        for i in range(self.nseg):
            lo_b = -1.0 if i == 0 else self.b[i]
            hi_b = 1e30 if i == self.nseg - 1 else self.b[i + 1]
            self.SEL.append(((zc >= lo_b) & (zc < hi_b)).astype(np.int64))
        self.T = []
        self.TAB = []
        for i in range(self.nseg):
            Di = self.M / 2 ** self.F[i]
            res = np.arange(2 ** self.Bp)
            zh = self.A[i] + np.mod(res * Di - self.A[i], self.L[i])
            zh = np.clip(zh, 0.0, D)
            T = np.clip(np.rint(self.scale * (self.fn(self.lo + zh) - self.ylo)), 0, 2 ** self.Bo - 1).astype(np.int64)
            self.T.append(T)
            tab = np.zeros(2 ** (self.Bp + 2), np.int64)
            tab[2 ** (self.Bp + 1):] = np.tile(T, 2)
            self.TAB.append(tab)
        self.gunit = self.M / 2.0 ** self.G

    # ---- integer protocol pieces -------------------------------------------------
    def z_int(self, x):
        z = np.clip(np.asarray(x, float) - self.lo, 0.0, self.D)
        return np.rint(z / self.gunit).astype(np.int64)

    def draw_r(self, rng, n):
        return rng.integers(0, 2 ** self.G, n, dtype=np.int64)

    def client_quantise(self, s_int):
        uc = s_int >> (self.G - self.Bc)
        us = np.stack([(s_int >> (self.G - F)) & (2 ** self.Bp - 1) for F in self.F])
        return uc, us

    def server_consts(self, r_int):
        cc = 2 ** self.Bc - (r_int >> (self.G - self.Bc))
        cs = np.stack([2 ** self.Bp - ((r_int >> (self.G - F)) & (2 ** self.Bp - 1)) for F in self.F])
        return cc, cs

    def reference_y1(self, uc, us, cc, cs):
        """exact integer evaluation of the server circuit up to (and excluding) the output mask"""
        vc = uc + cc
        y1 = np.zeros_like(uc)
        for i in range(self.nseg):
            sel = self.SEL[i][vc]
            idx = (us[i] + cs[i]) + (sel << (self.Bp + 1))
            y1 = y1 + self.TAB[i][idx]
        return y1

    def decode(self, y1):
        return np.asarray(y1, float) / self.scale + self.ylo

    def eval_plain(self, x, rng):
        """full protocol minus FHE (exact integers) with fresh random mask; returns real output"""
        zi = self.z_int(x)
        r = self.draw_r(rng, len(zi))
        s = (zi + r) % 2 ** self.G
        uc, us = self.client_quantise(s)
        cc, cs = self.server_consts(r)
        return self.decode(self.reference_y1(uc, us, cc, cs))


def precision(spec: SegSpec, n=200000, seed=0):
    """-log2 RMSE over inputs uniform in [lo, hi] (ROSETTA's metric: absolute error vs float reference)"""
    rng = np.random.default_rng(seed)
    x = rng.uniform(spec.lo, spec.hi, n)
    e = spec.eval_plain(x, rng) - spec.fn(x)
    return -math.log2(math.sqrt(np.mean(e ** 2))), float(np.max(np.abs(e)))


# =====================================================================================
#  FHE circuit (Concrete) for the segmented masked LUT
# =====================================================================================
from concrete import fhe


class SegMaskedLut:
    """Real TFHE evaluation of SegSpec.  Both parties are simulated in-process, but the code paths are
    separated exactly as in the protocol: client_* only touches (u, keys), server_* only touches the
    ciphertexts + clear constants derived from the server's own mask.
    The circuit takes ONE argument per segment (u_i, c_i): Concrete mis-compiles slices of tensors whose rows
    have different bit-widths, so no row indexing is used."""

    def __init__(self, spec: SegSpec, chunk=4, use_gpu=False, p_error=1e-10, strategy="mono", seed=0):
        self.spec, self.chunk = spec, chunk
        self.scalar = (chunk == 1)          # Concrete cannot compile shape-(1,) tensors: use true scalars
        sp, n, m = spec, spec.nseg, chunk
        self.n = n
        selT = [fhe.LookupTable([int(v) << (sp.Bp + 1) for v in t]) for t in sp.SEL]   # table emits 0 or 2^(Bp+1): no noisy constant multiply
        tabT = [fhe.LookupTable([int(v) for v in t]) for t in sp.TAB]
        Bo = sp.Bo
        mod_tab = fhe.LookupTable([int(x % (1 << Bo)) for x in range(1 << (Bo + 1))])
        car_tab = fhe.LookupTable([int(x >= (1 << Bo)) for x in range(1 << (Bo + 1))])
        xor_tab = fhe.LookupTable([0, 1, 0, 0])

        un = [f"u{i}" for i in range(n)]; cn = [f"c{i}" for i in range(n)]
        body = ["def fn(uc, cc, %s, r2, rho):" % ", ".join(un + cn), "    vc = uc + cc", "    y1 = None"]
        for i in range(n):
            body += [f"    sel{i} = selT[{i}][vc]", f"    yi{i} = tabT[{i}][u{i} + c{i} + sel{i}]",
                     f"    y1 = yi{i} if y1 is None else y1 + yi{i}"]
        body += ["    s = y1 + r2", "    return mod_tab[s], xor_tab[car_tab[s] + rho]"]
        ns = dict(selT=selT, tabT=tabT, mod_tab=mod_tab, car_tab=car_tab, xor_tab=xor_tab)
        exec("\n".join(body), ns)
        spec_args = {"uc": "encrypted", "cc": "clear", "r2": "clear", "rho": "clear",
                     **{k: "encrypted" for k in un}, **{k: "clear" for k in cn}}
        fn = fhe.compiler(spec_args)(ns["fn"])

        rng = np.random.default_rng(seed)
        ins = []
        # Concrete infers every bit-width from the inputset, so it MUST cover all segments and the extremes:
        # draws inside every segment (incl. its exact boundaries) + both ends of the domain.
        for i in range(sp.nseg):
            a, b = sp.tau[i], sp.tau[i + 1]
            for _ in range(12):
                ins.append(self._make_inputs(rng.uniform(a, b, m), rng))
            for edge in (a, b):
                for _ in range(4):
                    ins.append(self._make_inputs(np.full(m, edge), rng))
        for _ in range(30):
            ins.append(self._make_inputs(rng.uniform(sp.lo, sp.hi, m), rng))
        # mask extremes: r2 at its limits so s = y1 + r2 reaches its true maximum
        for r2v in (0, (1 << sp.Bo) - 1):
            for x in (np.full(m, sp.lo), np.full(m, sp.hi)):
                u = list(self._make_inputs(x, rng)); u[4] = np.full(m, r2v)
                ins.append(tuple(u))
        ins = [self._flat(t) for t in ins]
        cfg = fhe.Configuration(use_gpu=use_gpu, p_error=p_error, parameter_selection_strategy=strategy)
        t = time.time()
        self.circuit = fn.compile(ins, cfg)
        self.t_compile = time.time() - t
        t = time.time()
        self.circuit.keygen()
        self.t_keygen = time.time() - t
        self.client, self.server = self.circuit.client, self.circuit.server
        self.server_wrap = fhe.Client(self.server.client_specs)
        self.eval_keys = self.client.evaluation_keys

    # ---- helpers -------------------------------------------------------------------
    @staticmethod
    def _sq(a):
        a = np.asarray(a, np.int64)
        return a.reshape(a.shape[:-1]) if (a.ndim and a.shape[-1] == 1) else a

    def _flat(self, tup):
        """(uc, us[n,m], cc, cs[n,m], r2, rho) -> (uc, cc, u0..u{n-1}, c0..c{n-1}, r2, rho), scalars when chunk == 1"""
        uc, us, cc, cs, r2, rho = tup
        out = (uc, cc, *list(us), *list(cs), r2, rho)
        return tuple(self._sq(v) for v in out) if self.scalar else tuple(np.asarray(v, np.int64) for v in out)

    def _make_inputs(self, x, rng):
        sp = self.spec
        zi = sp.z_int(x)
        r = sp.draw_r(rng, len(zi))
        s = (zi + r) % 2 ** sp.G
        uc, us = sp.client_quantise(s)
        cc, cs = sp.server_consts(r)
        r2 = rng.integers(0, 1 << sp.Bo, len(zi))
        rho = rng.integers(0, 2, len(zi))
        return uc, us, cc, cs, r2, rho

    # ---- client ---------------------------------------------------------------------
    def client_encrypt(self, uc, us):
        n = self.n
        args = [self._sq(uc) if self.scalar else np.asarray(uc, np.int64), None] + \
               [self._sq(r) if self.scalar else np.asarray(r, np.int64) for r in us] + [None] * (n + 2)
        out = self.client.encrypt(*args)
        return out[0], list(out[2:2 + n])

    def client_decrypt(self, res):
        r = self.client.decrypt(res)
        return np.asarray(r[0], np.int64).reshape(-1), np.asarray(r[1], np.int64).reshape(-1)

    # ---- server ---------------------------------------------------------------------
    def server_run(self, enc_uc, enc_us, cc, cs, r2, rho):
        n = self.n
        cl = [self._sq(cc) if self.scalar else np.asarray(cc, np.int64)] + \
             [self._sq(r) if self.scalar else np.asarray(r, np.int64) for r in cs] + \
             [self._sq(r2) if self.scalar else np.asarray(r2, np.int64), self._sq(rho) if self.scalar else np.asarray(rho, np.int64)]
        w = self.server_wrap.encrypt(None, cl[0], *([None] * n), *cl[1:1 + n], cl[1 + n], cl[2 + n])
        return self.server.run(enc_uc, w[1], *enc_us, *w[2 + n:2 + 2 * n], w[2 + 2 * n], w[3 + 2 * n],
                               evaluation_keys=self.eval_keys)

    # ---- one chunk end-to-end ---------------------------------------------------------
    def run_chunk(self, x, rng):
        """returns (y1_fhe, y1_reference) as integers: y1 is the unmasked table value (server side)."""
        sp = self.spec
        uc, us, cc, cs, r2, rho = self._make_inputs(x, rng)
        w, kp = self.client_decrypt(self.server_run(*self.client_encrypt(uc, us), cc, cs, r2, rho))
        k = rho + (1 - 2 * rho) * kp
        y1 = w - r2 + (1 << sp.Bo) * k
        return y1, sp.reference_y1(uc, us, cc, cs)


def client_quantise_real(spec: SegSpec, s_real):
    """What the CLIENT really does: it decrypts the CKKS ciphertext (a real number s = z + r + CKKS noise),
    reduces it modulo M and quantises on the coarse grid and on every segment's fine grid."""
    s = np.mod(np.asarray(s_real, float), spec.M)
    uc = np.floor(s / spec.Dc).astype(np.int64) % (1 << spec.Bc)
    us = np.stack([np.floor(s / (spec.M / 2.0 ** F)).astype(np.int64) % (1 << spec.Bp) for F in spec.F])
    return uc, us
