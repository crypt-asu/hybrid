"""
TFHE side of the client-aided transcoding protocol (Concrete / Concrete-Python).

Elementwise masked lookup  y = f(x)  with perfect (one-time-pad) hiding in BOTH directions.

  client -> server :  u  = (x_q + r_q) mod 2^B                         [Enc_TFHE, client key]
  server clear     :  c  = 2^B - r_q ,  r2 in Z_{2^Bo} ,  rho in {0,1}   [never sent to client]
  server circuit   :  v  = u + c                       (in [0, 2^(B+1)),  v mod 2^B = x_q)
                      y1 = T[v]                        (T[v] = round(S*f(deq(v mod 2^B))), Bo bits)
                      s  = y1 + r2                     (in [0, 2^(Bo+1)))
                      w  = s mod 2^Bo                  (TLU)      -> uniform, independent of y1
                      k  = [s >= 2^Bo]                 (TLU)
                      k' = Xor[k + rho]                (= k xor rho, 2-bit TLU; uniform, independent of y1)
  server -> client :  (w, k')      client decrypts, re-encrypts under CKKS, sends back
  server (CKKS)    :  y1 = w - r2 + 2^Bo * (rho + (1-2 rho) k')      (all linear)

`mask_out=False` returns y1 directly (client sees f(x)); this is an ablation, NOT private.
"""
from __future__ import annotations
import time
from dataclasses import dataclass
import numpy as np
from concrete import fhe


@dataclass
class LutSpec:
    name: str
    fn: callable            # vectorised numpy float -> float
    lo: float
    hi: float
    B: int                  # input bits: grid of 2^B points over [lo, hi)
    out_scale: float        # y1 = round(out_scale * f(x)), clipped to [0, 2^Bo - 1]
    Bo: int
    chunk: int = 32
    mask_out: bool = True
    out_lo: float = 0.0     # y1 = round(out_scale*(f(x)-out_lo)); allows signed outputs

    @property
    def step(self):
        return (self.hi - self.lo) / (1 << self.B)

    def dequant(self, q):
        return self.lo + np.asarray(q, dtype=np.float64) * self.step

    def dequant_out(self, y):
        return np.asarray(y, dtype=np.float64) / self.out_scale + self.out_lo

    def quant(self, x):
        q = np.rint((np.asarray(x, dtype=np.float64) - self.lo) / self.step)
        return np.clip(q, 0, (1 << self.B) - 1).astype(np.int64)

    def table(self):
        v = np.arange(1 << (self.B + 1)) % (1 << self.B)
        y = np.rint(self.out_scale * (self.fn(self.dequant(v)) - self.out_lo))
        return np.clip(y, 0, (1 << self.Bo) - 1).astype(np.int64)

    def plain(self, x):
        """Exact integer-domain reference of what the encrypted pipeline computes (no FHE)."""
        return self.table()[self.quant(x)]


def _compile(fn, inputset, use_gpu, p_error, strategy="mono"):
    cfg = fhe.Configuration(use_gpu=use_gpu, p_error=p_error, parameter_selection_strategy=strategy)
    t = time.time()
    circ = fn.compile(inputset, cfg)
    t_compile = time.time() - t
    t = time.time()
    circ.keygen()
    return circ, t_compile, time.time() - t


class MaskedLut:
    def __init__(self, spec: LutSpec, use_gpu=False, p_error=1e-10, seed=0, strategy="mono"):
        assert spec.B + 1 <= 16 and spec.Bo + 1 <= 16
        self.spec = spec
        m, B, Bo = spec.chunk, spec.B, spec.Bo
        tab = fhe.LookupTable([int(t) for t in spec.table()])
        mod_tab = fhe.LookupTable([int(s % (1 << Bo)) for s in range(1 << (Bo + 1))])
        car_tab = fhe.LookupTable([int(s >= (1 << Bo)) for s in range(1 << (Bo + 1))])
        xor_tab = fhe.LookupTable([0, 1, 0, 0])
        rng = np.random.default_rng(seed)
        N = 1 << B
        if spec.mask_out:
            @fhe.compiler({"u": "encrypted", "c": "clear", "r2": "clear", "rho": "clear"})
            def fn(u, c, r2, rho):
                y1 = tab[u + c]
                s = y1 + r2
                return mod_tab[s], xor_tab[car_tab[s] + rho]
            ins = [(rng.integers(0, N, m), rng.integers(1, N + 1, m),
                    rng.integers(0, 1 << Bo, m), rng.integers(0, 2, m)) for _ in range(40)]
            ins.append((np.zeros(m, np.int64), np.ones(m, np.int64), np.zeros(m, np.int64), np.zeros(m, np.int64)))
            ins.append((np.full(m, N - 1), np.full(m, N), np.full(m, (1 << Bo) - 1), np.ones(m, np.int64)))
        else:
            @fhe.compiler({"u": "encrypted", "c": "clear"})
            def fn(u, c):
                return tab[u + c]
            ins = [(rng.integers(0, N, m), rng.integers(1, N + 1, m)) for _ in range(40)]
            ins.append((np.zeros(m, np.int64), np.ones(m, np.int64)))
            ins.append((np.full(m, N - 1), np.full(m, N)))
        self.circuit, self.t_compile, self.t_keygen = _compile(fn, ins, use_gpu, p_error, strategy)
        self.client = self.circuit.client
        self.server = self.circuit.server
        self.server_wrap = fhe.Client(self.server.client_specs)   # keyless: wraps the server's clear inputs
        self.eval_keys = self.client.evaluation_keys
        self.n_in = 4 if spec.mask_out else 2

    # --- client ------------------------------------------------------------------
    def client_encrypt(self, u):
        args = [np.asarray(u, np.int64)] + [None] * (self.n_in - 1)
        return self.client.encrypt(*args)[0]

    def client_decrypt(self, out):
        r = self.client.decrypt(out)
        if self.spec.mask_out:
            return np.asarray(r[0], np.int64), np.asarray(r[1], np.int64)
        return np.asarray(r, np.int64)

    # --- server ------------------------------------------------------------------
    def server_run(self, u_enc, c, r2=None, rho=None):
        clear = [np.asarray(c, np.int64)]
        if self.spec.mask_out:
            clear += [np.asarray(r2, np.int64), np.asarray(rho, np.int64)]
        w = self.server_wrap.encrypt(None, *clear)
        return self.server.run(u_enc, *w[1:], evaluation_keys=self.eval_keys)

    # --- one full masked chunk (both parties simulated in-process) ----------------
    def run_chunk(self, x_real, rng):
        """x_real: real values the SERVER holds in the clear *for testing only*; the protocol
        only ever hands the client u. Returns y1 (server-side unmasked integer outputs)."""
        spec = self.spec
        N = 1 << spec.B
        xq = spec.quant(x_real)
        rq = rng.integers(0, N, len(xq))
        u = (xq + rq) % N                       # what the client derives from CKKS-decrypt+quantize
        c = N - rq
        if not spec.mask_out:
            return self.client_decrypt(self.server_run(self.client_encrypt(u), c))
        r2 = rng.integers(0, 1 << spec.Bo, len(xq))
        rho = rng.integers(0, 2, len(xq))
        w, kp = self.client_decrypt(self.server_run(self.client_encrypt(u), c, r2, rho))
        k = rho + (1 - 2 * rho) * kp
        return w - r2 + (1 << spec.Bo) * k
