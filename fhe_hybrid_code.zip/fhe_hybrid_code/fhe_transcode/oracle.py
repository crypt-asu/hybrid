"""Correctness oracle (measurement instrument, NOT part of the protocol).
In the experiments both parties run in one process, so after the client decrypts the TFHE outputs we can compare them with the exact
integer evaluation of the same circuit (the table values are public design constants).  Every mismatch is a TFHE (PBS) failure.
The counters are attached to every benchmark record, so a failure can never be hidden inside an averaged precision number."""
import numpy as np
_S = {"elements": 0, "bad": 0}

def reset():
    _S["elements"] = 0; _S["bad"] = 0

def snapshot():
    return dict(_S)

def _acc(n, bad):
    _S["elements"] += int(n); _S["bad"] += int(bad)

def check_seg(spec, uc, us, cc, cs, r2, rho, w, kp):
    y1 = spec.reference_y1(np.asarray(uc, np.int64), np.asarray(us, np.int64), np.asarray(cc, np.int64), np.asarray(cs, np.int64))
    M = 1 << spec.Bo
    s = y1 + np.asarray(r2, np.int64)
    w_t = s % M; kp_t = (s >= M).astype(np.int64) ^ np.asarray(rho, np.int64)
    bad = np.sum((np.asarray(w).reshape(-1) != w_t.reshape(-1)) | (np.asarray(kp).reshape(-1) != kp_t.reshape(-1)))
    _acc(len(w_t.reshape(-1)), bad)

def check_taylor(spec, u, c, r2, rho, words):
    res = spec.res_of(np.asarray(u, np.int64), np.asarray(c, np.int64))
    bad = np.zeros(len(res), bool)
    for j, (lab, tab, b) in enumerate(spec.words()):
        M = 1 << b
        s = np.asarray(tab)[res] + np.asarray(r2[j], np.int64)
        w_t = s % M; kp_t = (s >= M).astype(np.int64) ^ np.asarray(rho[j], np.int64)
        w, kp = words[j]
        bad |= (np.asarray(w).reshape(-1) != w_t) | (np.asarray(kp).reshape(-1) != kp_t)
    _acc(len(res), bad.sum())
