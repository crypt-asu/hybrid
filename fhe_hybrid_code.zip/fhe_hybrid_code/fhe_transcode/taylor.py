"""
First-order ("linear interpolation") masked LUT for smooth bounded functions (GELU, SiLU, exp).
TFHE returns THREE masked words per element, all functions of the same unmasked cell index res = floor((z+eps)/step):
    T[res]  = f(x_0)                   (Bo bits)
    A[res]  = f'(x_0)                  (Bs bits)
    R[res]  = res                      (B  bits)
The server (CKKS, ciphertext x still available exactly) completes   y = T + A * (x - x_c),
x_0 = lo + res*step (the table point; the quantiser's random offset eps in [0,step) only widens |x-x_0| to <= step). One ct*ct multiplication.
"""
from __future__ import annotations
import math
from dataclasses import dataclass
import numpy as np


@dataclass
class TaylorSpec:
    name: str
    fn: callable
    dfn: callable
    lo: float
    hi: float
    B: int
    Bo: int
    Bs: int
    G: int = 40
    guard: bool = True             # one guard cell above hi: inputs in [lo, hi] never wrap around when the quantiser carry adds +1
    slope_ratio: float = None      # if f'(x) = slope_ratio * f(x) (exp): the slope word A is not needed (saves 4 PBS/element)

    def __post_init__(self):
        assert self.B + 1 <= 16 and self.Bs + 1 <= 16 and self.Bo <= 30
        self.Bh = self.Bo // 2 if self.Bo > 15 else 0           # T split in two digits when it does not fit one TLU
        self.Bl = self.Bo - self.Bh
        assert self.Bl + 1 <= 16 and self.Bh + 1 <= 16
        # guard cell: the client's quantisation carry can move an input in cell a to cell a+1 (res = a + carry), so the
        # table has 2^B cells of width step = (hi-lo)/(2^B-1); inputs in [lo, hi] occupy cells 0..2^B-2 and the carry never wraps.
        self.step = (self.hi - self.lo) / (2 ** self.B - 1) if self.guard else (self.hi - self.lo) / 2 ** self.B
        self.D = self.step * 2 ** self.B
        g = np.linspace(self.lo, self.lo + self.D, 20001)
        v = self.fn(g); d = self.slope_ratio * v if self.slope_ratio is not None else self.dfn(g)
        self.Tlo, Thi = float(v.min()), float(v.max())
        self.Alo, Ahi = float(d.min()), float(d.max())
        self.Tsc = (2 ** self.Bo - 1) / (Thi - self.Tlo)
        self.Asc = (2 ** self.Bs - 1) / (Ahi - self.Alo)
        res = np.arange(2 ** self.B)
        xc = self.lo + res * self.step                       # expansion point = table point (left edge of the grid cell)
        self.Ttab = np.clip(np.rint(self.Tsc * (self.fn(xc) - self.Tlo)), 0, 2 ** self.Bo - 1).astype(np.int64)
        self.Rtab = res.astype(np.int64)
        self.Atab = None if self.slope_ratio is not None else np.clip(np.rint(self.Asc * (self.dfn(xc) - self.Alo)), 0, 2 ** self.Bs - 1).astype(np.int64)
        self.gunit = self.D / 2.0 ** self.G

    # -- exact integer pipeline (what the FHE circuit computes), then real-valued completion --
    def draw_r(self, rng, n):
        return rng.integers(0, 2 ** self.G, n, dtype=np.int64)

    def client_quantise(self, s_real):
        return np.floor(np.mod(s_real, self.D) / self.step).astype(np.int64) % (1 << self.B)

    def server_consts(self, r_int):
        return (1 << self.B) - (r_int >> (self.G - self.B))

    def eps(self, r_int):
        return (r_int & ((1 << (self.G - self.B)) - 1)) * self.gunit

    def res_of(self, u, c):
        return (u + c) % (1 << self.B)

    def complete(self, x, T_i, A_i, R_i, r_int):
        """CKKS-side formula in floating point (the CKKS circuit does exactly these linear ops + one ct*ct)."""
        T = T_i / self.Tsc + self.Tlo
        x0 = self.lo + R_i * self.step                       # same point the TFHE tables were built at
        if self.slope_ratio is not None:
            return T * (1.0 + self.slope_ratio * (x - x0))
        A = A_i / self.Asc + self.Alo
        return T + A * (x - x0)

    def eval_plain(self, x, rng):
        x = np.asarray(x, float); n = len(x)
        r = self.draw_r(rng, n)
        z = np.clip(x - self.lo, 0, self.D - self.step * 1e-9)
        s = np.mod(z + r * self.gunit, self.D)               # what the client decrypts (mod D), exact arithmetic
        u = self.client_quantise(s); c = self.server_consts(r)
        res = self.res_of(u, c)
        return self.complete(x, self.Ttab[res], None if self.Atab is None else self.Atab[res], res, r)


def precision(spec, n=200000, seed=0, const_only=False):
    rng = np.random.default_rng(seed)
    x = rng.uniform(spec.lo, spec.hi if spec.guard else spec.hi - spec.step, n)
    y = spec.eval_plain(x, rng)
    e = y - spec.fn(x)
    return -math.log2(math.sqrt(np.mean(e ** 2))), float(np.max(np.abs(e)))


    # ------------------------------------------------------------------ words returned by TFHE
def _words(self):
    """list of (label, table over cell index res, bit-width)"""
    w = []
    if self.Bh:
        w += [("Thi", self.Ttab >> self.Bl, self.Bh), ("Tlo", self.Ttab & ((1 << self.Bl) - 1), self.Bl)]
    else:
        w += [("T", self.Ttab, self.Bo)]
    if self.slope_ratio is None:
        w += [("A", self.Atab, self.Bs)]
    w += [("R", self.Rtab, self.B)]
    return w
TaylorSpec.words = _words


# =====================================================================================
#  FHE circuit
# =====================================================================================
import time
from concrete import fhe


class TaylorMaskedLut:
    """TFHE evaluation: one encrypted input u -> several output words, each one-time-padded (mod 2^W mask + xor-hidden carry)."""

    def __init__(self, spec: TaylorSpec, chunk=4, use_gpu=False, p_error=1e-10, strategy="mono", seed=0):
        self.spec, self.chunk = spec, chunk
        B = spec.B
        N = 1 << B
        W = spec.words()
        self.nw = nw = len(W)
        self.bits = [b for (_, _, b) in W]
        tabs = [fhe.LookupTable([int(t[v % N]) for v in range(2 * N)]) for (_, t, _) in W]
        mods = [fhe.LookupTable([int(x % (1 << b)) for x in range(1 << (b + 1))]) for b in self.bits]
        cars = [fhe.LookupTable([int(x >= (1 << b)) for x in range(1 << (b + 1))]) for b in self.bits]
        xor_tab = fhe.LookupTable([0, 1, 0, 0])

        # one clear argument per word (Concrete mis-compiles slices of tensors whose rows have different bit-widths)
        rn = [f"r{j}" for j in range(nw)]; hn = [f"h{j}" for j in range(nw)]
        body = ["def fn(u, c, %s):" % ", ".join(rn + hn), "    v = u + c", "    outs = []"]
        for j in range(nw):
            body += [f"    s{j} = tabs[{j}][v] + r{j}", f"    outs.append(mods[{j}][s{j}])",
                     f"    outs.append(xor_tab[cars[{j}][s{j}] + h{j}])"]
        body.append("    return tuple(outs)")
        ns = dict(tabs=tabs, mods=mods, cars=cars, xor_tab=xor_tab)
        exec("\n".join(body), ns)
        spec_args = {"u": "encrypted", "c": "clear", **{k: "clear" for k in rn + hn}}
        fn = fhe.compiler(spec_args)(ns["fn"])

        rng = np.random.default_rng(seed)
        m = chunk

        def mk(u, c):
            r2 = [rng.integers(0, 1 << b, m) for b in self.bits]
            rho = [rng.integers(0, 2, m) for _ in range(nw)]
            return (u, c, *r2, *rho)
        ins = [mk(rng.integers(0, N, m), rng.integers(1, N + 1, m)) for _ in range(60)]
        ins.append((np.zeros(m, np.int64), np.ones(m, np.int64), *[np.zeros(m, np.int64)] * nw, *[np.zeros(m, np.int64)] * nw))
        ins.append((np.full(m, N - 1), np.full(m, N), *[np.full(m, (1 << b) - 1) for b in self.bits], *[np.ones(m, np.int64)] * nw))
        cfg = fhe.Configuration(use_gpu=use_gpu, p_error=p_error, parameter_selection_strategy=strategy)
        t = time.time()
        self.circuit = fn.compile(ins, cfg)
        self.t_compile = time.time() - t
        t = time.time(); self.circuit.keygen(); self.t_keygen = time.time() - t
        self.client, self.server = self.circuit.client, self.circuit.server
        self.server_wrap = fhe.Client(self.server.client_specs)
        self.eval_keys = self.client.evaluation_keys

    def client_encrypt(self, u):
        return self.client.encrypt(np.asarray(u, np.int64), *([None] * (1 + 2 * self.nw)))[0]

    def client_decrypt(self, res):
        r = self.client.decrypt(res)
        return [(np.asarray(r[2 * j], np.int64), np.asarray(r[2 * j + 1], np.int64)) for j in range(self.nw)]

    def server_run(self, enc_u, c, r2, rho):
        cl = [np.asarray(c, np.int64)] + [np.asarray(r, np.int64) for r in r2] + [np.asarray(h, np.int64) for h in rho]
        w = self.server_wrap.encrypt(None, *cl)
        return self.server.run(enc_u, *w[1:], evaluation_keys=self.eval_keys)
