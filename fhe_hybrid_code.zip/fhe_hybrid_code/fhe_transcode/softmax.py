"""
Private max-free softmax, ROSETTA's normalise-and-square formulation, with ALL nonlinear steps in TFHE:
    y_i <- exp(z_i / 2^k)                       TFHE (single masked LUT), n elements
    repeat k times:   s <- sum_j y_j^2          CKKS (ct*ct, slot-sum; s is replicated in every slot)
                      r <- 1/s                  TFHE (segmented masked LUT on ONE scalar) + CKKS Newton refinement
                      y_i <- y_i^2 * r          CKKS
  => softmax(z)_i      (identity: softmax(2x)_i = y_i^2 / sum_j y_j^2 with y = softmax-numerator of x).
Reciprocal ranges (derived, not assumed): round 1: s in [n e^-2, n e^2] (since y in [e^-1, e] when k = log2 M);
rounds >= 2: sum y = 1  =>  s in [1/n, 1].
"""
from __future__ import annotations
import math, time
import numpy as np
from .tfhe_ops import LutSpec, MaskedLut
from .seglut import SegSpec, SegMaskedLut
from .ckks_layer import transcode_lut, transcode_nonlinear, transcode_taylor, newton_inv
from .taylor import TaylorSpec, TaylorMaskedLut


class PrivateSoftmax:
    def __init__(self, n, M, B=10, Bo=10, rec=dict(nseg=4, Bp=8, Bc=10, Bo=12), use_gpu=False, p_error=1e-10, exp_mode='lut', Bt=22, Bs=13):
        self.n, self.M = n, float(M)
        self.k = int(round(math.log2(M)))
        assert 2 ** self.k == M, "M must be a power of two (k = log2 M)"
        k = self.k
        self.f_exp = lambda z: np.exp(z / 2 ** k)
        ylo, yhi = math.exp(-M / 2 ** k), math.exp(M / 2 ** k)
        self.exp_spec = LutSpec("exp_k", self.f_exp, -self.M, self.M, B, (2 ** Bo - 1) / (yhi - ylo), Bo, chunk=n, out_lo=ylo)
        self.exp_mode = exp_mode
        if exp_mode == 'taylor':     # first-order exp: ~16 PBS/element instead of 4, much higher precision
            dexp = lambda z: np.exp(z / 2 ** k) / 2 ** k
            self.exp_tspec = TaylorSpec("exp_k", self.f_exp, dexp, -self.M, self.M, B, Bt, Bs)
            self.exp_lut = TaylorMaskedLut(self.exp_tspec, chunk=n, use_gpu=use_gpu, p_error=p_error)
        elif exp_mode == 'taylor1':   # first-order exp with f' = f / 2^k : only the value word T and the cell index R (8 PBS/element)
            self.exp_tspec = TaylorSpec("exp_k", self.f_exp, None, -self.M, self.M, B, Bt, 1, slope_ratio=1.0 / 2 ** k)
            self.exp_lut = TaylorMaskedLut(self.exp_tspec, chunk=n, use_gpu=use_gpu, p_error=p_error)
        else:
            self.exp_lut = MaskedLut(self.exp_spec, use_gpu=use_gpu, p_error=p_error)
        inv = lambda x: 1.0 / x
        self.rec1 = SegSpec("1/s_round1", inv, n * math.exp(-2), n * math.exp(2), rec["nseg"], rec["Bp"], rec["Bc"], rec["Bo"], True)
        self.recn = SegSpec("1/s_roundN", inv, 1.0 / n, 1.0, rec["nseg"], rec["Bp"], rec["Bc"], rec["Bo"], True)
        self.rec1_lut = SegMaskedLut(self.rec1, chunk=1, use_gpu=use_gpu, p_error=p_error)
        self.recn_lut = SegMaskedLut(self.recn, chunk=1, use_gpu=use_gpu, p_error=p_error)

    def __call__(self, ck, ct_z, rng, newton_iters=1, log=None):
        its = newton_iters if isinstance(newton_iters, (list, tuple)) else [newton_iters] * self.k   # per-round Newton schedule
        n = self.n
        t = time.time()
        y, _ = (transcode_taylor(ck, self.exp_lut, ct_z, n, rng) if self.exp_mode in ('taylor', 'taylor1')
                else transcode_lut(ck, self.exp_lut, ct_z, n, rng))
        if log: log(f"  exp over {n} elements (TFHE): {time.time()-t:.1f}s")
        for j in range(self.k):
            y2 = ck.cc.EvalMult(y, y)
            s = ck.cc.EvalSum(y2, ck.slots)                     # total in EVERY slot (padding slots are zero)
            spec, lut = (self.rec1, self.rec1_lut) if j == 0 else (self.recn, self.recn_lut)
            t = time.time()
            r0, _ = transcode_nonlinear(ck, lut, spec, s, 1, rng, tile_n=1)   # r0 replicated in all slots
            r = newton_inv(ck, s, r0, its[j]) if its[j] else r0
            if log: log(f"  round {j+1}/{self.k}: reciprocal of the sum (TFHE+Newton): {time.time()-t:.1f}s")
            y = ck.cc.EvalMult(y2, r)
        return y
