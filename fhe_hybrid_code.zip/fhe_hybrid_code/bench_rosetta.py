"""
ROSETTA-style micro-benchmarks for the client-aided transcoding design (all nonlinear ops in TFHE, linear in CKKS).
    python bench_rosetta.py table9  [--samples S]      1/x and 1/sqrt(x), ranges [0.01,10], [0.01,100]   (ROSETTA Table 9)
    python bench_rosetta.py table10 [--samples S]      GELU, SiLU on [-20,20]                           (Table 10)
    python bench_rosetta.py table6  [--dims 768,2048,4096] [--s2 150,8192]                              (Table 6)
    python bench_rosetta.py table4  [--n 512] [--M 8,16,32,128]                                         (Table 4)
Every number printed is measured; precision = -log2 RMSE (absolute) between the decrypted FHE result and the float reference.
Results are appended (JSON lines) to results.jsonl together with hardware information.
"""
import sys, os, json, time, math, platform, subprocess, argparse
import numpy as np
from scipy.special import erf
from fhe_transcode import oracle
from fhe_transcode.ckks_layer import Ckks, transcode_nonlinear, transcode_taylor, newton_inv, newton_rsqrt
from fhe_transcode.seglut import SegSpec, SegMaskedLut, precision as seg_precision
from fhe_transcode.taylor import TaylorSpec, TaylorMaskedLut, precision as tay_precision

ap = argparse.ArgumentParser(); ap.add_argument("table"); ap.add_argument("--samples", type=int, default=12)
ap.add_argument("--dims", default="768,2048,4096"); ap.add_argument("--s2", default="150,8192")
ap.add_argument("--n", default="512"); ap.add_argument("--M", default="8,16,32,128"); ap.add_argument("--out", default="results.jsonl"); ap.add_argument("--runs", type=int, default=5); ap.add_argument("--only", default=""); ap.add_argument("--kind", default="rms,layer")
args = ap.parse_args()

def sh(c):
    try: return subprocess.run(c, shell=True, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception: return ""
HW = dict(cpu=sh("lscpu | grep 'Model name' | head -1 | cut -d: -f2").strip() or platform.processor(), cores=os.cpu_count(),
          gpu=sh("nvidia-smi --query-gpu=name --format=csv,noheader") or "none", concrete_on_gpu=False, python=platform.python_version())
def emit(rec):
    rec["hardware"] = HW; rec["time"] = time.strftime("%Y-%m-%d %H:%M:%S")
    rec["tfhe_oracle"] = oracle.snapshot(); oracle.reset()      # elements checked / elements whose TFHE output differed from the exact integer circuit
    print("RESULT", json.dumps(rec), flush=True)
    open(args.out, "a").write(json.dumps(rec) + "\n")
bits = lambda e: float(-np.log2(np.sqrt(np.mean(np.square(e)))))

# ------------------------------------------------------------------------------------------------ Table 9
if args.table == "table9":
    S = args.samples
    ck = Ckks(depth=10, slots=max(16, 1 << math.ceil(math.log2(S))))
    for fname, f, nw, hi, rec in (("1/x", lambda x: 1 / x, newton_inv, 10.0, dict(nseg=4, Bp=10, Bc=12, Bo=15)),
                                  ("1/x", lambda x: 1 / x, newton_inv, 100.0, dict(nseg=4, Bp=10, Bc=13, Bo=15)),
                                  ("1/sqrt(x)", lambda x: 1 / np.sqrt(x), newton_rsqrt, 10.0, dict(nseg=4, Bp=10, Bc=12, Bo=15)),
                                  ("1/sqrt(x)", lambda x: 1 / np.sqrt(x), newton_rsqrt, 100.0, dict(nseg=4, Bp=10, Bc=13, Bo=15))):
        _i = globals().get("_i", -1) + 1; globals()["_i"] = _i if _i < 3 else -1
        if args.only and str(_i if _i>=0 else 3) not in args.only.split(","): continue
        lo = 0.01
        sp = SegSpec(fname, f, lo, hi, rec["nseg"], rec["Bp"], rec["Bc"], rec["Bo"], True)
        sim = {it: None for it in (0, 1, 2)}
        rng = np.random.default_rng(0)
        # exact-integer simulation (identical to FHE when FHE is exact) over 2e5 uniform inputs
        xs = rng.uniform(lo, hi, 200000); y0 = sp.eval_plain(xs, rng)
        for it in (0, 1, 2):
            y = y0
            for _ in range(it): y = (y * (2 - xs * y)) if nw is newton_inv else (y * (1.5 - 0.5 * xs * y * y))
            sim[it] = bits(y - f(xs))
        # real FHE: S samples (half uniform, half log-uniform to hit the steep region), vector circuit
        Lv = SegMaskedLut(sp, chunk=S)
        x = rng.uniform(lo, hi, S)                       # ROSETTA: inputs sampled uniformly from the target range
        ct = ck.enc(x); t = time.time(); r0, _ = transcode_nonlinear(ck, Lv, sp, ct, S, rng); t_vec = time.time() - t
        fhe = {}
        for it in (0, 1, 2):
            r = nw(ck, ct, r0, it) if it else r0
            fhe[it] = bits(ck.dec(r, S) - f(x))
        # scalar latency (chunk=1), 2 runs
        Ls = SegMaskedLut(sp, chunk=1); lat = []
        for _ in range(2):
            ct1 = ck.enc(np.array([rng.uniform(lo, hi)])); t = time.time()
            r0s, _ = transcode_nonlinear(ck, Ls, sp, ct1, 1, rng, tile_n=1); r1 = nw(ck, ct1, r0s, 1) if True else r0s
            lat.append(time.time() - t)
        emit(dict(table="9", fn=fname, range=[lo, hi], cfg=rec, tfhe_p_error=Ls.circuit.p_error, pbs_per_scalar=int(Ls.circuit.programmable_bootstrap_count),
                  internal_plain_model_bits={str(k): v for k, v in sim.items()}, fhe_precision_bits_S_samples={str(k): v for k, v in fhe.items()}, S=S,
                  latency_scalar_s=float(np.mean(lat)), latency_vector_s=t_vec))

# ------------------------------------------------------------------------------------------------ Table 9, fewer-segment configs (3 Newton)
if args.table == "pareto9":
    S = args.samples
    ck = Ckks(depth=14, slots=max(16, 1 << math.ceil(math.log2(S))))
    for fname, f, nw, hi, rec in (("1/x", lambda x: 1 / x, newton_inv, 10.0, dict(nseg=2, Bp=8, Bc=9, Bo=10)),
                                  ("1/x", lambda x: 1 / x, newton_inv, 100.0, dict(nseg=3, Bp=9, Bc=10, Bo=15)),
                                  ("1/sqrt(x)", lambda x: 1 / np.sqrt(x), newton_rsqrt, 10.0, dict(nseg=2, Bp=8, Bc=9, Bo=10)),
                                  ("1/sqrt(x)", lambda x: 1 / np.sqrt(x), newton_rsqrt, 100.0, dict(nseg=2, Bp=9, Bc=9, Bo=10))):
        _i = globals().get("_i", -1) + 1; globals()["_i"] = _i if _i < 3 else -1
        if args.only and str(_i if _i>=0 else 3) not in args.only.split(","): continue
        lo = 0.01
        sp = SegSpec(fname, f, lo, hi, rec["nseg"], rec["Bp"], rec["Bc"], rec["Bo"], True)
        rng = np.random.default_rng(0)
        xs = rng.uniform(lo, hi, 200000); y0 = sp.eval_plain(xs, rng); sim = {}
        for it in (0, 1, 2, 3):
            y = y0
            for _ in range(it): y = (y * (2 - xs * y)) if nw is newton_inv else (y * (1.5 - 0.5 * xs * y * y))
            sim[it] = bits(y - f(xs))
        Lv = SegMaskedLut(sp, chunk=S)
        x = rng.uniform(lo, hi, S)                       # ROSETTA: inputs sampled uniformly from the target range
        ct = ck.enc(x); t = time.time(); r0, _ = transcode_nonlinear(ck, Lv, sp, ct, S, rng); t_vec = time.time() - t
        fhe = {}
        for it in (0, 1, 2, 3):
            r = nw(ck, ct, r0, it) if it else r0
            fhe[it] = bits(ck.dec(r, S) - f(x))
        Ls = SegMaskedLut(sp, chunk=1); lat = []
        for _ in range(2):
            ct1 = ck.enc(np.array([rng.uniform(lo, hi)])); t = time.time()
            r0s, _ = transcode_nonlinear(ck, Ls, sp, ct1, 1, rng, tile_n=1); r1 = nw(ck, ct1, r0s, 3)
            lat.append(time.time() - t)
        emit(dict(table="9-fast", fn=fname, range=[lo, hi], cfg=rec, tfhe_p_error=Ls.circuit.p_error, pbs_per_scalar=int(Ls.circuit.programmable_bootstrap_count),
                  internal_plain_model_bits={str(k): v for k, v in sim.items()}, fhe_precision_bits_S_samples={str(k): v for k, v in fhe.items()}, S=S,
                  latency_scalar_s_3newton=float(np.mean(lat)), latency_vector_s=t_vec))

# ------------------------------------------------------------------------------------------------ Table 10
if args.table == "table10":
    S = args.samples
    ck = Ckks(depth=8, slots=max(16, 1 << math.ceil(math.log2(S))))
    sig = lambda x: 1 / (1 + np.exp(-x))
    FN = {"GELU": (lambda x: 0.5 * x * (1 + erf(x / np.sqrt(2))), lambda x: 0.5 * (1 + erf(x / np.sqrt(2))) + x * np.exp(-x * x / 2) / np.sqrt(2 * np.pi)),
          "SiLU": (lambda x: x * sig(x), lambda x: sig(x) * (1 + x * (1 - sig(x))))}
    for name, (f, d) in FN.items():
        for B in (10, 11):
            sp = TaylorSpec(name, f, d, -20., 20., B, 22, 13)
            sim, _ = tay_precision(sp)
            L = TaylorMaskedLut(sp, chunk=S); rng = np.random.default_rng(1)
            x = rng.uniform(-20, 20, S); x[:2] = [20.0, -20.0]      # table edges included on purpose
            t = time.time(); y_ct, _ = transcode_taylor(ck, L, ck.enc(x), S, rng); dt = time.time() - t
            emit(dict(table="10", fn=name, range=[-20, 20], cfg=dict(B=B, Bo=22, Bs=13), pbs_per_element=int(L.circuit.programmable_bootstrap_count) // S,
                      tfhe_p_error=L.circuit.p_error, internal_plain_model_bits=sim, fhe_precision_bits_S_samples=bits(ck.dec(y_ct, S) - f(x)), S=S, latency_per_element_s=dt / S, latency_total_s=dt))

# ------------------------------------------------------------------------------------------------ Table 6
if args.table == "table6":
    from fhe_transcode.norm import PrivateNorm
    R = args.runs
    for d in map(int, args.dims.split(",")):
        for s2 in map(float, args.s2.split(",")):
            vrange = (0.2, 150.0) if s2 <= 200 else (1.0, 8192.0)           # ROSETTA: per-group variance sampled from these ranges
            rec = dict(nseg=4, Bp=10, Bc=12 if s2 <= 200 else 14, Bo=15)
            for kind in args.kind.split(","):
                nm = PrivateNorm(d, kind, 1.2 * s2, rec=rec)               # 20 % headroom: the SAMPLE variance of d draws can exceed the nominal maximum
                ck = Ckks(depth=15, slots=nm.slots, sum_keys=True); rng = np.random.default_rng(2); runs = []; errs = []
                for v in rng.uniform(vrange[0], vrange[1], R):
                    x = rng.normal(0, 1, d) * np.sqrt(v)                    # zero-mean normal, as in ROSETTA
                    g = rng.uniform(0.5, 1.5, d); b = rng.normal(0, 0.1, d) if kind == "layer" else None
                    var = (np.mean(x ** 2) if kind == "rms" else np.var(x)) + nm.eps
                    ref = g * ((x if kind == "rms" else x - x.mean()) / np.sqrt(var)) + (0 if b is None else b)
                    pad = lambda a: None if a is None else np.pad(a, (0, nm.slots - d))
                    t = time.time(); y_ct, _ = nm(ck, ck.enc(x), pad(g), pad(b), rng, 2); dt = time.time() - t
                    e = ck.dec(y_ct, d) - ref; errs.append(e)
                    runs.append(dict(variance=float(v), sample_variance=float(var), precision_bits=bits(e), latency_s=dt))
                emit(dict(table="6", kind=kind, d=d, variance_range=list(vrange), sigma2_max_table=1.2 * s2, cfg=rec, newton_iters=2, tfhe_p_error=nm.lut.circuit.p_error,
                          precision_bits_pooled=bits(np.concatenate(errs)), latency_mean_s=float(np.mean([r["latency_s"] for r in runs])), runs=runs))
                del nm, ck

# ------------------------------------------------------------------------------------------------ Table 4
if args.table == "table4":
    from fhe_transcode.softmax import PrivateSoftmax
    for n in map(int, args.n.split(",")):
        for M in map(int, args.M.split(",")):
            k = int(round(math.log2(M)))
            base = 4 * k + 2                       # CKKS levels needed with one Newton step (measured: k=3 -> 14); each further Newton step costs +2
            if base > 29:                          # OpenFHE accepts at most depth 29 at N=2^16 / 128-bit
                emit(dict(table="4", n=n, M=M, k=k, skipped=f"needs CKKS depth {base} > 29 (maximum accepted at N=2^16, 128-bit security)"))
                continue
            n_newton = min(k, 1 + (29 - base) // 2)
            sched = [1] * n_newton + [0] * (k - n_newton)
            depth = base + 2 * (n_newton - 1)
            sm = PrivateSoftmax(n, M, B=9, Bt=15, rec=dict(nseg=4, Bp=10, Bc=12, Bo=15), exp_mode="taylor1")
            ck = Ckks(depth=depth, slots=max(16, 1 << math.ceil(math.log2(n))), sum_keys=True)
            rng = np.random.default_rng(3)
            z = np.clip(rng.normal(0, M / math.sqrt(3), n), -M, M)                           # N(0, M^2/3) truncated to [-M, M], edges allowed
            ref = np.exp(z - z.max()); ref /= ref.sum()
            logs = []
            t = time.time(); y = sm(ck, ck.enc(z), rng, sched, log=logs.append); dt = time.time() - t
            out = ck.dec(y, n)
            emit(dict(table="4", n=n, M=M, k=k, ckks_depth=depth, exp_mode="taylor1(B=9,Bt=15)", newton_schedule=sched,
                      exp_pbs_per_element=int(sm.exp_lut.circuit.programmable_bootstrap_count) // n,
                      precision_bits=bits(out - ref), sum_of_outputs=float(out.sum()), latency_s=dt, stage_log=[l.strip() for l in logs]))
            del sm, ck
