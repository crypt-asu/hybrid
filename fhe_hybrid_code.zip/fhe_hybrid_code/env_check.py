"""
Environment check for the client-aided CKKS<->TFHE transcoding experiments.
Run this FIRST on the Colab A100 runtime and send me the complete output.

    python env_check.py            # auto: uses GPU for Concrete if the GPU wheel is active
    python env_check.py --cpu      # force CPU

It reports measured facts only (no estimates).
"""
import sys, os, time, platform, subprocess, resource, importlib.metadata as md
import numpy as np

def sh(cmd):
    try:
        return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=60).stdout.strip()
    except Exception as e:
        return f"<{e}>"

print("python        :", platform.python_version())
print("cpu count     :", os.cpu_count())
print("RAM (GB)      :", sh("free -g | awk '/Mem:/ {print $2}'"))
print("nvidia-smi    :", sh("nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader") or "<none>")
print("nvcc          :", sh("nvcc --version | tail -1") or "<none>")

for pkg in ["concrete-python", "openfhe", "numpy", "torch", "transformers"]:
    try:
        print(f"{pkg:14s}:", md.version(pkg))
    except Exception:
        print(f"{pkg:14s}: NOT INSTALLED")

import concrete.compiler as ccomp
gpu_enabled = ccomp.check_gpu_enabled()      # wheel built with CUDA support
gpu_avail = ccomp.check_gpu_available()      # a CUDA device is visible
print("Concrete GPU wheel enabled :", gpu_enabled)
print("Concrete CUDA device found :", gpu_avail)
use_gpu = (gpu_enabled and gpu_avail) and ("--cpu" not in sys.argv)
print("=> Concrete will run on    :", "GPU" if use_gpu else "CPU")
gname = sh("nvidia-smi --query-gpu=name --format=csv,noheader")
if "A100" not in gname: print("!! WARNING: GPU is '%s', not an A100. State the real GPU in any paper." % (gname or "none"))

# ---- OpenFHE CKKS at the ROSETTA ring dimension (N = 2^16) ----------------------------
from openfhe import *
p = CCParamsCKKSRNS()
p.SetMultiplicativeDepth(13); p.SetScalingModSize(41); p.SetFirstModSize(53)
p.SetRingDim(1 << 16); p.SetSecurityLevel(SecurityLevel.HEStd_128_classic)
p.SetScalingTechnique(ScalingTechnique.FLEXIBLEAUTO); p.SetBatchSize(1 << 12)
t = time.time(); cc = GenCryptoContext(p)
cc.Enable(PKESchemeFeature.PKE); cc.Enable(PKESchemeFeature.KEYSWITCH); cc.Enable(PKESchemeFeature.LEVELEDSHE)
kp = cc.KeyGen(); cc.EvalMultKeyGen(kp.secretKey)
x = np.random.default_rng(0).normal(size=64)
ct = cc.Encrypt(kp.publicKey, cc.MakeCKKSPackedPlaintext(x.tolist()))
m = cc.EvalMult(ct, ct)
pt = cc.Decrypt(m, kp.secretKey); pt.SetLength(64)
err = np.max(np.abs(np.array(pt.GetRealPackedValue()) - x * x))
print(f"OpenFHE CKKS N={cc.GetRingDimension()} depth=13: setup {time.time()-t:.1f}s, ct*ct max err {err:.2e}")

# ---- Concrete: exact masked-LUT round trip, each config in its own process (OOM-safe) ---------
here = os.path.dirname(os.path.abspath(__file__))
for B, Bo in [(6, 6), (8, 8), (12, 10), (14, 12)]:
    cmd = [sys.executable, "-u", "-W", "ignore", os.path.join(here, "test_masked_lut.py"), str(B), str(Bo), "1"]
    if not use_gpu: cmd.append("--cpu")
    t = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=here, timeout=3000)
    out = (r.stdout.strip().splitlines() or [""])[-1]
    print(out if r.returncode == 0 else f"B={B} Bo={Bo}: FAILED rc={r.returncode} (137 = out of memory) {r.stderr.strip()[-200:]}")
