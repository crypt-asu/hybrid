"""usage: python stress.py B Bo chunk trials [--cpu]   -> counts wrong elements (real FHE vs exact integer reference)"""
import sys, numpy as np, time
import concrete.compiler as ccomp
from fhe_transcode.tfhe_ops import LutSpec, MaskedLut
B,Bo,chunk,trials = map(int, sys.argv[1:5])
use_gpu = ccomp.check_gpu_enabled() and ccomp.check_gpu_available() and '--cpu' not in sys.argv
spec = LutSpec("exp", np.exp, lo=-12.8, hi=0.0, B=B, out_scale=float(2**Bo-1), Bo=Bo, chunk=chunk)
L = MaskedLut(spec, use_gpu=use_gpu); print('gpu =', use_gpu, '| p_error reported:', L.circuit.p_error, flush=True)
rng = np.random.default_rng(7); N=1<<B; bad_w=bad_k=tot=0; t0=time.time()
for tr in range(trials):
    x=rng.uniform(-12.7,-0.01,chunk); xq=spec.quant(x); rq=rng.integers(0,N,chunk); u=(xq+rq)%N; c=N-rq
    r2=rng.integers(0,1<<Bo,chunk); rho=rng.integers(0,2,chunk)
    w,kp=L.client_decrypt(L.server_run(L.client_encrypt(u),c,r2,rho))
    s=spec.table()[xq]+r2; w_t=s%(1<<Bo); kp_t=(s>=(1<<Bo)).astype(int)^rho
    bw=np.where(w!=w_t)[0]; bk=np.where(kp!=kp_t)[0]; bad_w+=len(bw); bad_k+=len(bk); tot+=chunk
    if len(bw) or len(bk):
        for i in set(bw)|set(bk): print(f"  FAIL trial{tr} el{i}: xq={xq[i]} u={u[i]} c={c[i]} r2={r2[i]} rho={rho[i]} w={w[i]}!={w_t[i]} kp={kp[i]}/{kp_t[i]}", flush=True)
print(f"elements={tot} bad_w={bad_w} bad_kp={bad_k} time={time.time()-t0:.0f}s", flush=True)
