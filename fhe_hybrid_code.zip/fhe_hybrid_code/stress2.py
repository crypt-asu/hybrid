"""usage: python stress2.py B Bo chunk trials p_error strategy [seed]   (p_error 'none' = default)"""
import sys, numpy as np, time
from fhe_transcode.tfhe_ops import LutSpec, MaskedLut
B,Bo,chunk,trials = map(int, sys.argv[1:5])
pe = None if sys.argv[5]=='none' else float(sys.argv[5]); strat = sys.argv[6]
spec = LutSpec("exp", np.exp, lo=-12.8, hi=0.0, B=B, out_scale=float(2**Bo-1), Bo=Bo, chunk=chunk)
L = MaskedLut(spec, p_error=pe, strategy=strat)
print('cfg', sys.argv[1:], '| reported p_error:', L.circuit.p_error, '| keygen %.1fs'%L.t_keygen, flush=True)
seed = int(sys.argv[7]) if len(sys.argv) > 7 else 7
rng = np.random.default_rng(seed); N=1<<B; bad=tot=0; t0=time.time()
for tr in range(trials):
    x=rng.uniform(-12.7,-0.01,chunk); xq=spec.quant(x); rq=rng.integers(0,N,chunk); u=(xq+rq)%N; c=N-rq
    r2=rng.integers(0,1<<Bo,chunk); rho=rng.integers(0,2,chunk)
    w,kp=L.client_decrypt(L.server_run(L.client_encrypt(u),c,r2,rho))
    s=spec.table()[xq]+r2; w_t=s%(1<<Bo); kp_t=(s>=(1<<Bo)).astype(int)^rho
    b=np.where((w!=w_t)|(kp!=kp_t))[0]; bad+=len(b); tot+=chunk
    for i in b: print(f"  FAIL trial{tr} el{i}: y1={spec.table()[xq][i]} r2={r2[i]} w={w[i]}!={w_t[i]} kp={kp[i]}/{kp_t[i]}", flush=True)
print(f"RESULT cfg={sys.argv[1:]} elements={tot} bad={bad} time={time.time()-t0:.0f}s", flush=True)
