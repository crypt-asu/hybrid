"""C8 (advisor): measured effect of one standard size reduction on the server-to-client message: modulus-switch the masked CKKS ciphertext to
fewer primes before sending it.  The masked ciphertext is reduced (LevelReduce) to every possible level; for each level the script measures the
serialised size and checks that the client still decrypts s mod M correctly (largest circular error versus the exact value).
Not measured here: seeded symmetric encryption (not exposed by the OpenFHE Python API we use), packing w and k' in one ciphertext, key-size reduction.
Usage: python c8_comm_opt.py [--depth 12] [--out results_c8.jsonl]"""
import sys, os, json, tempfile, argparse, time
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from openfhe import SerializeToFile, BINARY
from fhe_transcode.ckks_layer import Ckks
from fhe_transcode.seglut import SegSpec
ap = argparse.ArgumentParser(); ap.add_argument("--depth", type=int, default=12); ap.add_argument("--out", default="results_c8.jsonl"); args = ap.parse_args()
spec = SegSpec("rsqrt_var", lambda x: 1.0 / np.sqrt(x), 0.01, 150.0, 4, 10, 12, 15, True)
ck = Ckks(depth=args.depth, slots=1024); tmp = tempfile.mkdtemp(); rng = np.random.default_rng(1)
def size(ct):
    f = os.path.join(tmp, "ct.bin"); SerializeToFile(f, ct, BINARY); return os.path.getsize(f)
z = np.array([3.0]); r_int = spec.draw_r(rng, 1)
res = []
for lv in range(0, ck.L):
    ct = ck.enc(z, tile_n=1)
    ct_s = ck.add_plain(ct, r_int * spec.gunit + ck.wide_offset(rng, 1, spec.M, ct) - spec.lo, 1)
    try:
        if lv: ct_s = ck.cc.LevelReduce(ct_s, None, lv)
        sv = ck.dec(ct_s, 1)
        a = np.mod(sv, spec.M)[0]; b = np.mod(z[0] - spec.lo + r_int[0] * spec.gunit, spec.M)
        err = abs(a - b); err = min(err, spec.M - err)
        res.append(dict(levels_dropped=lv, primes_left=int(ck.L + 1 - ct_s.GetLevel()), bytes=size(ct_s), max_error=float(err), decrypts_ok=bool(err < spec.Dc / 8)))
    except Exception as e:
        res.append(dict(levels_dropped=lv, error=str(e)[:120]))
effective = len({r.get("bytes") for r in res if "bytes" in r}) > 1
rec = dict(levelreduce_changed_size=effective, depth=args.depth, primes_in_context=ck.L + 1, results=res, note="single scalar in a 1024-slot ciphertext; serialised with OpenFHE BINARY", time=time.strftime("%Y-%m-%d %H:%M:%S"))
print(json.dumps(rec), flush=True); open(args.out, "a").write(json.dumps(rec) + "\n")

if not effective:
    print("WARNING: LevelReduce did not change the serialised size or level in this OpenFHE build; NO size-reduction claim can be made from this run.", flush=True)
