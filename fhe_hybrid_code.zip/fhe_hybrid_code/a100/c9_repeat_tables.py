"""C9 / C11 / C12 / C13 (advisor): repeat the paper's table experiments R times with fresh inputs and fresh masks, and record, for every run,
precision, MAXIMUM absolute error, maximum relative error, per-sample absolute errors, the number of oracle-checked elements and the stage times
(vector TFHE call, scalar call, cumulative time after t Newton steps).  The circuits, specs and routines are those of bench_rosetta.py
(nothing is re-implemented): SegSpec / TaylorSpec / SegMaskedLut / TaylorMaskedLut / transcode_nonlinear / transcode_taylor / newton_* / PrivateNorm.
  --table 9      standard configuration (4 segments), t = 0,1,2 Newton steps; latency of the scalar call with t = 1 and t = 2
  --table 9f     fewer-segment configurations, t = 0..3; latency with t = 3
  --table 10     GELU / SiLU, B = 10, 11
  --table 6      LayerNorm / RMSNorm at d (default 768); `--mean MU` adds a non-zero mean MU*sigma to every input (C13); 0 = ROSETTA's zero-mean case
  --gpu          use the GPU backend of Concrete (needs the GPU build of concrete-python); results then belong to the GPU machine's hardware row
Usage: python c9_repeat_tables.py --table 9 --repeats 10 --samples 64 [--gpu] --out results_c9.jsonl"""
import sys, os, json, time, math, argparse, platform, subprocess
import numpy as np
from scipy.special import erf
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fhe_transcode import oracle
from fhe_transcode.ckks_layer import Ckks, transcode_nonlinear, transcode_taylor, newton_inv, newton_rsqrt
from fhe_transcode.seglut import SegSpec, SegMaskedLut
from fhe_transcode.taylor import TaylorSpec, TaylorMaskedLut
ap = argparse.ArgumentParser(); ap.add_argument("--table", required=True, choices=["9", "9f", "10", "6"])
ap.add_argument("--repeats", type=int, default=10); ap.add_argument("--samples", type=int, default=64); ap.add_argument("--gpu", action="store_true")
ap.add_argument("--d", type=int, default=768); ap.add_argument("--s2", default="150,8192"); ap.add_argument("--kind", default="rms,layer")
ap.add_argument("--mean", type=float, default=0.0); ap.add_argument("--only", default=""); ap.add_argument("--out", default="results_c9.jsonl")
args = ap.parse_args()
def sh(c):
    try: return subprocess.run(c, shell=True, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception: return ""
HW = dict(cpu=sh("lscpu | grep 'Model name' | head -1 | cut -d: -f2").strip() or platform.processor(), cores=os.cpu_count(),
          gpu=sh("nvidia-smi --query-gpu=name --format=csv,noheader") or "none", concrete_on_gpu=bool(args.gpu), python=platform.python_version())
bits = lambda e: float(-np.log2(np.sqrt(np.mean(np.square(e)))))
def emit(rec):
    rec["hardware"] = HW; rec["time"] = time.strftime("%Y-%m-%d %H:%M:%S"); rec["oracle"] = oracle.snapshot(); oracle.reset()
    print("RESULT", json.dumps({k: v for k, v in rec.items() if k not in ("runs",)})[:600], flush=True)
    open(args.out, "a").write(json.dumps(rec) + "\n")
def errstats(y, ref):
    e = y - ref
    return dict(precision_bits=bits(e), max_abs_error=float(np.max(np.abs(e))), max_rel_error=float(np.max(np.abs(e) / np.maximum(np.abs(ref), 1e-30))), abs_errors=[float(v) for v in np.abs(e)])
S = args.samples; R = args.repeats
oracle.reset()

if args.table in ("9", "9f"):
    fast = args.table == "9f"
    ck = Ckks(depth=14 if fast else 10, slots=max(16, 1 << math.ceil(math.log2(S))))
    if fast:
        cfgs = (("1/x", lambda x: 1 / x, newton_inv, 10.0, dict(nseg=2, Bp=8, Bc=9, Bo=10)), ("1/x", lambda x: 1 / x, newton_inv, 100.0, dict(nseg=3, Bp=9, Bc=10, Bo=15)),
                ("1/sqrt(x)", lambda x: 1 / np.sqrt(x), newton_rsqrt, 10.0, dict(nseg=2, Bp=8, Bc=9, Bo=10)), ("1/sqrt(x)", lambda x: 1 / np.sqrt(x), newton_rsqrt, 100.0, dict(nseg=2, Bp=9, Bc=9, Bo=10)))
        tmax = 3
    else:
        cfgs = (("1/x", lambda x: 1 / x, newton_inv, 10.0, dict(nseg=4, Bp=10, Bc=12, Bo=15)), ("1/x", lambda x: 1 / x, newton_inv, 100.0, dict(nseg=4, Bp=10, Bc=13, Bo=15)),
                ("1/sqrt(x)", lambda x: 1 / np.sqrt(x), newton_rsqrt, 10.0, dict(nseg=4, Bp=10, Bc=12, Bo=15)), ("1/sqrt(x)", lambda x: 1 / np.sqrt(x), newton_rsqrt, 100.0, dict(nseg=4, Bp=10, Bc=13, Bo=15)))
        tmax = 2
    for ci, (fname, f, nw, hi, rec) in enumerate(cfgs):
        if args.only and str(ci) not in args.only.split(","): continue
        lo = 0.01
        sp = SegSpec(fname, f, lo, hi, rec["nseg"], rec["Bp"], rec["Bc"], rec["Bo"], True)
        Lv = SegMaskedLut(sp, chunk=S, use_gpu=args.gpu); Ls = SegMaskedLut(sp, chunk=1, use_gpu=args.gpu)
        runs = []
        for rep in range(R):
            rng = np.random.default_rng(1000 + rep)
            x = rng.uniform(lo, hi, S); ct = ck.enc(x)
            t = time.time(); r0, _ = transcode_nonlinear(ck, Lv, sp, ct, S, rng); t_vec = time.time() - t
            per_t = {}
            for it in range(tmax + 1):
                r = nw(ck, ct, r0, it) if it else r0
                per_t[str(it)] = errstats(ck.dec(r, S), f(x))
            lat = []
            for _ in range(2):
                x1 = rng.uniform(lo, hi); ct1 = ck.enc(np.array([x1]))
                t = time.time(); r0s, _ = transcode_nonlinear(ck, Ls, sp, ct1, 1, rng, tile_n=1); t_tr = time.time() - t
                cum = {"0": t_tr}
                for it in range(1, tmax + 1):
                    t = time.time(); nw(ck, ct1, r0s, it); cum[str(it)] = t_tr + (time.time() - t)
                lat.append(cum)
            runs.append(dict(seed=1000 + rep, t_vector_call_s=t_vec, per_newton_steps=per_t, scalar_latency_cumulative_s=lat))
        emit(dict(table="9f" if fast else "9", fn=fname, range=[lo, hi], cfg=rec, repeats=R, S=S, tfhe_p_error=Ls.circuit.p_error,
                  pbs_per_scalar=int(Ls.circuit.programmable_bootstrap_count), runs=runs))

if args.table == "10":
    ck = Ckks(depth=8, slots=max(16, 1 << math.ceil(math.log2(S))))
    sig = lambda x: 1 / (1 + np.exp(-x))
    FN = {"GELU": (lambda x: 0.5 * x * (1 + erf(x / np.sqrt(2))), lambda x: 0.5 * (1 + erf(x / np.sqrt(2))) + x * np.exp(-x * x / 2) / np.sqrt(2 * np.pi)),
          "SiLU": (lambda x: x * sig(x), lambda x: sig(x) * (1 + x * (1 - sig(x))))}
    for name, (f, d) in FN.items():
        for B in (10, 11):
            sp = TaylorSpec(name, f, d, -20., 20., B, 22, 13)
            L = TaylorMaskedLut(sp, chunk=S, use_gpu=args.gpu); runs = []
            for rep in range(R):
                rng = np.random.default_rng(2000 + rep)
                x = rng.uniform(-20, 20, S); x[:2] = [20.0, -20.0]
                t = time.time(); y_ct, _ = transcode_taylor(ck, L, ck.enc(x), S, rng); dt = time.time() - t
                runs.append(dict(seed=2000 + rep, latency_total_s=dt, latency_per_element_s=dt / S, **errstats(ck.dec(y_ct, S), f(x))))
            emit(dict(table="10", fn=name, cfg=dict(B=B, Bo=22, Bs=13), repeats=R, S=S, pbs_per_element=int(L.circuit.programmable_bootstrap_count) // S, runs=runs))

if args.table == "6":
    from fhe_transcode.norm import PrivateNorm
    d = args.d
    for s2 in map(float, args.s2.split(",")):
        vrange = (0.2, 150.0) if s2 <= 200 else (1.0, 8192.0)
        recc = dict(nseg=4, Bp=10, Bc=12 if s2 <= 200 else 14, Bo=15)
        for kind in args.kind.split(","):
            nm = PrivateNorm(d, kind, 1.2 * s2, rec=recc, use_gpu=args.gpu)
            ck = Ckks(depth=15, slots=nm.slots, sum_keys=True); runs = []
            for rep in range(R):
                rng = np.random.default_rng(3000 + rep)
                vmax = vrange[1] / (1.0 + args.mean ** 2) if kind == "rms" else vrange[1]  # RMSNorm uses the mean square v(1+mu^2): keep it inside the table range
                v = rng.uniform(vrange[0], max(vmax, vrange[0] + 1e-6))
                x = args.mean * np.sqrt(v) + rng.normal(0, 1, d) * np.sqrt(v)
                g = rng.uniform(0.5, 1.5, d); b = rng.normal(0, 0.1, d) if kind == "layer" else None
                var = (np.mean(x ** 2) if kind == "rms" else np.var(x)) + nm.eps
                ref = g * ((x if kind == "rms" else x - x.mean()) / np.sqrt(var)) + (0 if b is None else b)
                pad = lambda a: None if a is None else np.pad(a, (0, nm.slots - d))
                t = time.time(); y_ct, _ = nm(ck, ck.enc(x), pad(g), pad(b), rng, 2); dt = time.time() - t
                runs.append(dict(seed=3000 + rep, variance=float(v), sample_variance=float(var), in_table_range=bool(var <= 1.2 * s2), latency_s=dt, **errstats(ck.dec(y_ct, d), ref)))
            emit(dict(table="6", kind=kind, d=d, variance_range=list(vrange), mean_in_sigma_units=args.mean, newton_iters=2, repeats=R, cfg=recc,
                      tfhe_p_error=nm.lut.circuit.p_error, runs=runs))
            del nm, ck
