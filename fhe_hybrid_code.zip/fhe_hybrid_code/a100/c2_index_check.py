"""C2 (advisor): how is the off-by-one of the quantised indices absorbed, and how large is its effect?
Exact integer arithmetic only (no FHE, no CKKS noise): for the segmented tables of the paper's table experiments this script
  (a) counts how often the coarse index sum  u_c + c_c  and the fine index sum  u_i + c_i  of the SELECTED segment differ from the exact
      floor(z/Delta) of the unmasked value z, and by how much (never silently assumed: the maximum difference is reported);
  (b) reports the largest difference between neighbouring entries of every fine table (the worst effect of a one-cell index shift,
      in output units and in function units);
  (c) reports the margin (in coarse cells) that the segment windows were built with.
Usage: python c2_index_check.py [--samples 2000000] [--out results_c2.jsonl]"""
import sys, os, json, argparse, math
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fhe_transcode.seglut import SegSpec
ap = argparse.ArgumentParser(); ap.add_argument("--samples", type=int, default=2_000_000); ap.add_argument("--out", default="results_c2.jsonl")
args = ap.parse_args()
CONFIGS = [  # exactly the SegSpec of the table experiments (bench_rosetta.py table9 / table6)
    ("1/x", (0.01, 10.0), lambda x: 1 / x, dict(nseg=4, Bp=10, Bc=12, Bo=15)),
    ("1/x", (0.01, 100.0), lambda x: 1 / x, dict(nseg=4, Bp=10, Bc=13, Bo=15)),
    ("1/sqrt(x)", (0.01, 10.0), lambda x: 1 / np.sqrt(x), dict(nseg=4, Bp=10, Bc=12, Bo=15)),
    ("1/sqrt(x)", (0.01, 100.0), lambda x: 1 / np.sqrt(x), dict(nseg=4, Bp=10, Bc=13, Bo=15)),
]
rng = np.random.default_rng(11)
for name, (lo, hi), fn, c in CONFIGS:
    sp = SegSpec(name, fn, lo, hi, c["nseg"], c["Bp"], c["Bc"], c["Bo"], True)
    n = args.samples
    x = rng.uniform(lo, hi, n)
    zi = sp.z_int(x); r = sp.draw_r(rng, n)
    s = (zi + r) % 2 ** sp.G
    uc, us = sp.client_quantise(s); cc, cs = sp.server_consts(r)
    # coarse index: reconstructed (mod 2^Bc) versus exact floor(z / Dc)
    vc = (uc + cc) % 2 ** sp.Bc
    z_c = (zi >> (sp.G - sp.Bc)) % 2 ** sp.Bc
    dc = (vc - z_c) % 2 ** sp.Bc
    coarse_hist = {int(k): int(v) for k, v in zip(*np.unique(dc, return_counts=True))}
    # fine index per segment
    fine = []
    for i, F in enumerate(sp.F):
        vi = (us[i] + cs[i]) % 2 ** sp.Bp
        z_i = (zi >> (sp.G - F)) % 2 ** sp.Bp
        di = (vi - z_i) % 2 ** sp.Bp
        fine.append({int(k): int(v) for k, v in zip(*np.unique(di, return_counts=True))})
    # worst effect of a one-cell shift inside each fine table
    shifts = []
    for i in range(sp.nseg):
        T = sp.T[i].astype(np.int64)
        d = np.abs(np.diff(T)).max()
        shifts.append(dict(segment=i, max_adjacent_diff_output_units=int(d), max_adjacent_diff_function_units=float(d / sp.scale)))
    # protocol output (exact integers) versus function value
    y1 = sp.reference_y1(uc, us, cc, cs)
    err = np.abs(sp.decode(y1) - fn(x))
    rec = dict(fn=name, range=[lo, hi], cfg=c, samples=n, margin_cells=sp.margin_cells, coarse_cell_width=sp.Dc,
               coarse_index_difference_counts=coarse_hist, fine_index_difference_counts_per_segment=fine,
               table_adjacent_difference=shifts, max_abs_error_exact_integer_pipeline=float(err.max()),
               note="exact integer arithmetic, no FHE and no CKKS noise; difference 0 = exact, 1 = neighbouring cell")
    print(json.dumps(rec), flush=True); open(args.out, "a").write(json.dumps(rec) + "\n")
