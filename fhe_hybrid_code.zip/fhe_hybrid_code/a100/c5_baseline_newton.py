"""C5 (advisor), stronger same-machine baseline: pure-CKKS Chebyshev initial guess (OpenFHE EvalChebyshevFunction) followed by t Newton steps
(the SAME newton_inv / newton_rsqrt routines the hybrid protocol uses), for 1/x and 1/sqrt(x) on ROSETTA's ranges.  No TFHE, no client rounds.
Also reports the time of every stage separately.  Precision = -log2 RMSE (absolute) over uniform samples; one ciphertext holds `--slots` values.
A Newton iteration costs 2 levels (1/x) or 3 levels (1/sqrt x); the chain is built with depth = Chebyshev depth + levels of the Newton steps (<= 29).
Usage: python c5_baseline_newton.py [--slots 4096] [--degrees 59,119,247] [--steps 0,1,2,3] [--out results_c5.jsonl]"""
import sys, os, json, time, math, argparse, platform
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from openfhe import *
from fhe_transcode.ckks_layer import Ckks, newton_inv, newton_rsqrt
ap = argparse.ArgumentParser(); ap.add_argument("--slots", type=int, default=4096); ap.add_argument("--degrees", default="59,119,247")
ap.add_argument("--steps", default="0,1,2,3"); ap.add_argument("--out", default="results_c5.jsonl"); args = ap.parse_args()
CH_DEPTH = {59: 6, 119: 7, 247: 8, 495: 9}
rng = np.random.default_rng(5)
HW = dict(cores=os.cpu_count(), python=platform.python_version())
bits = lambda e: float(-np.log2(np.sqrt(np.mean(np.square(e)))))
for fn_name, f, newton, per in (("1/x", lambda x: 1 / x, newton_inv, 2), ("1/sqrt(x)", lambda x: 1 / np.sqrt(x), newton_rsqrt, 3)):
    for hi in (10.0, 100.0):
        lo = 0.01
        x = rng.uniform(lo, hi, args.slots)
        for deg in map(int, args.degrees.split(",")):
            for t in map(int, args.steps.split(",")):
                depth = CH_DEPTH[deg] + per * t
                if depth > 29:
                    continue
                ck = Ckks(depth=depth, slots=args.slots, spare=1)   # one level above the documented Chebyshev depth (OpenFHE needs it, as in the baseline of Table baseline)
                ct = ck.enc(x)
                t0 = time.time()
                y = ck.cc.EvalChebyshevFunction(lambda v: float(f(v)), ct, lo, hi, deg)
                t_cheb = time.time() - t0
                t1 = time.time()
                if t: y = newton(ck, ct, y, t)
                t_new = time.time() - t1
                out = ck.dec(y, args.slots)
                rec = dict(fn=fn_name, range=[lo, hi], chebyshev_degree=deg, newton_steps=t, ckks_depth=depth, ckks_chain_levels=depth + 1, slots=args.slots,
                           precision_bits=bits(out - f(x)) if np.all(np.isfinite(out)) else None, max_abs_error=float(np.max(np.abs(out - f(x)))) if np.all(np.isfinite(out)) else None,
                           time_chebyshev_s=t_cheb, time_newton_s=t_new, time_total_s=t_cheb + t_new, hardware=HW, time=time.strftime("%Y-%m-%d %H:%M:%S"),
                           method="pure CKKS: OpenFHE EvalChebyshevFunction + Newton (no TFHE)")
                print(json.dumps(rec), flush=True); open(args.out, "a").write(json.dumps(rec) + "\n")
                del ck
