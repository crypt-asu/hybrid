"""C16 (advisor): check the TFHE parameters Concrete chose, with an independent lattice estimator.
Step 1 (always): compile the paper's TFHE circuits, read the parameters from the compiled program (LWE secret-key dimensions and types, bootstrapping-key
GLWE parameters and noise variances, key-switching-key parameters) and write them to JSON.  Concrete's noise "variance" is normalised to the torus;
the standard deviation in Z_q is sqrt(variance) * 2^64.
Step 2 (needs the lattice estimator, https://github.com/malb/lattice-estimator, run inside SageMath or with its Python dependencies): for every
LWE instance (secret-key LWE of dimension n, GLWE of dimension k*N seen as LWE, key switching) call LWE.estimate and write the estimated cost
(log2 of the best attack) next to the parameters.  If the estimator cannot be imported the script stops after step 1 and says so; nothing is invented.
Usage: python c16_lattice_estimate.py --out params_lattice.json [--estimator-path /path/to/lattice-estimator]"""
import sys, os, json, math, argparse
import numpy as np
from scipy.special import erf
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ap = argparse.ArgumentParser(); ap.add_argument("--out", default="params_lattice.json"); ap.add_argument("--estimator-path", default=""); args = ap.parse_args()
from fhe_transcode.tfhe_ops import LutSpec, MaskedLut
from fhe_transcode.seglut import SegSpec, SegMaskedLut
from fhe_transcode.taylor import TaylorSpec, TaylorMaskedLut
gelu = lambda x: 0.5 * x * (1 + erf(x / np.sqrt(2))); dgelu = lambda x: 0.5 * (1 + erf(x / np.sqrt(2))) + x * np.exp(-x * x / 2) / np.sqrt(2 * np.pi)
circuits = {
    "stress_exp8": lambda: MaskedLut(LutSpec("exp", np.exp, -12.8, 0.0, B=8, out_scale=255.0, Bo=8, chunk=4)),
    "seg_rsqrt_chunk1": lambda: SegMaskedLut(SegSpec("rsqrt_var", lambda x: 1 / np.sqrt(x), 0.01, 180.0, 4, 10, 12, 15, True), chunk=1),
    "seg_inv100_chunk4": lambda: SegMaskedLut(SegSpec("1/x", lambda x: 1 / x, 0.01, 100.0, 4, 10, 13, 15, True), chunk=4),
    "taylor_gelu11_chunk4": lambda: TaylorMaskedLut(TaylorSpec("GELU", gelu, dgelu, -20., 20., 11, 22, 13), chunk=4),
    "taylor_exp_softmax_chunk4": lambda: TaylorMaskedLut(TaylorSpec("exp_k", lambda z: np.exp(z / 8), None, -8., 8., 9, 15, 1, slope_ratio=1 / 8), chunk=4),
}
out = {}
for name, mk in circuits.items():
    L = mk()
    ks = json.loads(L.circuit.server.client_specs.program_info.serialize())["keyset"]
    out[name] = dict(p_error=L.circuit.p_error, global_p_error=L.circuit.global_p_error,
                     lwe_secret_keys=[dict(id=k["id"], dimension=k["params"]["lweDimension"], key_type=k["params"]["keyType"]) for k in ks["lweSecretKeys"]],
                     bootstrap_keys=[dict(glwe_dimension=b["params"]["glweDimension"], polynomial_size=b["params"]["polynomialSize"], levels=b["params"]["levelCount"],
                                          base_log=b["params"]["baseLog"], noise_variance=b["params"]["variance"]) for b in ks["lweBootstrapKeys"]],
                     keyswitch_keys=[dict(input_dimension=q["params"]["inputLweDimension"], output_dimension=q["params"]["outputLweDimension"], levels=q["params"]["levelCount"],
                                          base_log=q["params"]["baseLog"], noise_variance=q["params"]["variance"]) for q in ks["lweKeyswitchKeys"]],
                     ciphertext_modulus_bits=64)
    print(name, json.dumps(out[name])[:400], flush=True)
    del L
json.dump(out, open(args.out, "w"), indent=1)
if args.estimator_path: sys.path.insert(0, args.estimator_path)
try:
    from estimator import LWE, ND
    from sage.all import oo
except Exception as e:
    print("lattice estimator NOT available (%s). Parameters were written to %s; run this script where the estimator is installed." % (type(e).__name__, args.out)); sys.exit(0)
q = 2 ** 64
def est(n, var, key_type, full=False):
    sd = math.sqrt(var) * q
    Xs = ND.UniformMod(2)      # Concrete uses binary LWE/GLWE secret keys (key_type is "binary" in the JSON)
    params = LWE.Parameters(n=n, q=q, Xs=Xs, Xe=ND.DiscreteGaussian(sd), m=oo)
    if full:
        r = LWE.estimate(params, deny_list=("arora-gb", "bkw"))               # all remaining attacks, estimator default reduction cost model
    else:
        r = LWE.estimate.rough(params)                                       # fast usvp + dual-hybrid only
    return {k: float(math.log2(v["rop"])) for k, v in r.items()}
FULL = os.environ.get("C16_FULL", "0") == "1"
for name, d in out.items():
    sk = {k["id"]: k for k in d["lwe_secret_keys"]}
    d["estimator_mode"] = "full" if FULL else "rough"
    d["estimates_log2_rop"] = dict(
        bootstrap=[est(b["glwe_dimension"] * b["polynomial_size"], b["noise_variance"], "binary", FULL) for b in d["bootstrap_keys"]],
        keyswitch=[est(k["output_dimension"], k["noise_variance"], "binary", FULL) for k in d["keyswitch_keys"]])
    print(name, "estimates", json.dumps(d["estimates_log2_rop"]), flush=True)
json.dump(out, open(args.out, "w"), indent=1)
