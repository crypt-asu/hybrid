"""C6 / C9 (advisor): softmax in ROSETTA's settings in ONE process (no segmentation, one set of CKKS keys), for larger n and R, with repeats and
the metrics the advisor asked for: precision (-log2 RMSE), maximum absolute error, maximum relative error, KL divergence KL(ref || out), sum of outputs.
Same configuration as bench_rosetta.py table4 (taylor1 exp with B=9, Bt=15; segmented reciprocal; Newton schedule from the level budget; CKKS depth <= 29).
R is the softmax range [-R, R] (ROSETTA's M).  Configurations whose depth exceeds 29 are skipped and recorded as such (R = 128 needs depth 30).
Usage: FHE_GPU=1 python c6_softmax_repeat.py --n 512,1024,2048 --R 8,16,32 --repeats 3 --out results_c6.jsonl
(--gpu or FHE_GPU=1 selects the GPU backend of Concrete; memory: the n >= 1024 exp circuit needs a machine with much more RAM than the 7 GB Machine A.)"""
import sys, os, json, math, time, argparse, platform, subprocess
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fhe_transcode import oracle
from fhe_transcode.ckks_layer import Ckks
from fhe_transcode.softmax import PrivateSoftmax
ap = argparse.ArgumentParser(); ap.add_argument("--n", default="512"); ap.add_argument("--R", default="8"); ap.add_argument("--repeats", type=int, default=3)
ap.add_argument("--gpu", action="store_true"); ap.add_argument("--out", default="results_c6.jsonl"); args = ap.parse_args()
GPU = args.gpu or os.environ.get("FHE_GPU") == "1"
def sh(c):
    try: return subprocess.run(c, shell=True, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception: return ""
HW = dict(cpu=sh("lscpu | grep 'Model name' | head -1 | cut -d: -f2").strip() or platform.processor(), cores=os.cpu_count(),
          gpu=sh("nvidia-smi --query-gpu=name --format=csv,noheader") or "none", concrete_on_gpu=GPU, ram_gb=round(os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES') / 2 ** 30, 1), python=platform.python_version())
bits = lambda e: float(-np.log2(np.sqrt(np.mean(np.square(e)))))
for n in map(int, args.n.split(",")):
    for Rr in map(int, args.R.split(",")):
        k = int(round(math.log2(Rr))); base = 4 * k + 2
        if base > 29:
            rec = dict(n=n, R=Rr, k=k, skipped=f"needs CKKS depth {base} > 29", hardware=HW)
            print(json.dumps(rec), flush=True); open(args.out, "a").write(json.dumps(rec) + "\n"); continue
        n_newton = min(k, 1 + (29 - base) // 2); sched = [1] * n_newton + [0] * (k - n_newton); depth = base + 2 * (n_newton - 1)
        t0 = time.time()
        sm = PrivateSoftmax(n, Rr, B=9, Bt=15, rec=dict(nseg=4, Bp=10, Bc=12, Bo=15), exp_mode="taylor1", use_gpu=GPU)
        ck = Ckks(depth=depth, slots=max(16, 1 << math.ceil(math.log2(n))), sum_keys=True)
        t_setup = time.time() - t0
        runs = []
        for rep in range(args.repeats):
            rng = np.random.default_rng(3 + rep)
            z = np.clip(rng.normal(0, Rr / math.sqrt(3), n), -Rr, Rr)
            ref = np.exp(z - z.max()); ref /= ref.sum()
            logs = []; oracle.reset()
            t = time.time(); y = sm(ck, ck.enc(z), rng, sched, log=logs.append); dt = time.time() - t
            out = ck.dec(y, n); e = out - ref
            kl = float(np.sum(ref * np.log(ref / np.maximum(out, 1e-30))))
            runs.append(dict(seed=3 + rep, precision_bits=bits(e), max_abs_error=float(np.max(np.abs(e))), max_rel_error=float(np.max(np.abs(e) / ref)), kl_divergence=kl,
                             sum_of_outputs=float(out.sum()), min_output=float(out.min()), latency_s=dt, oracle=oracle.snapshot(), stage_log=[l.strip() for l in logs]))
            print("RUN", json.dumps({k_: v for k_, v in runs[-1].items() if k_ != "stage_log"}), flush=True)
        rec = dict(n=n, R=Rr, k=k, ckks_depth=depth, newton_schedule=sched, exp_pbs_per_element=int(sm.exp_lut.circuit.programmable_bootstrap_count) // n,
                   setup_s=t_setup, repeats=args.repeats, runs=runs, hardware=HW, single_process=True, time=time.strftime("%Y-%m-%d %H:%M:%S"))
        open(args.out, "a").write(json.dumps(rec) + "\n")
        del sm, ck
