"""C4 (advisor): decoder error of  s mod M  after CKKS decryption of the wide-masked ciphertext, expressed RELATIVE to the finest table cell
width, for the configurations of the paper's table experiments (not only M = 128 of the probe table).
For each configuration the CKKS context has the depth of that experiment (+1 spare level).  The masked ciphertext is measured after k = 0, 1, 2, ... multiplications by 1.0 (each consumes one level in FLEXIBLEAUTO, which rescales lazily),
until decryption fails (maximum error above M/8) or the chain ends; so the error includes the noise of k rescalings and the first depth at which the wide mask no longer decrypts is reported.
The truth is  (z + r_int*g) mod M  computed in double precision on numbers below 2M (exact to about 2^-45).
Usage: python c4_decoder_vs_cell.py [--slots 4096] [--trials 3] [--out results_c4.jsonl]"""
import sys, os, json, math, argparse, time, platform
import numpy as np
from scipy.special import erf
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fhe_transcode.ckks_layer import Ckks
from fhe_transcode.seglut import SegSpec
from fhe_transcode.taylor import TaylorSpec
ap = argparse.ArgumentParser(); ap.add_argument("--slots", type=int, default=4096); ap.add_argument("--trials", type=int, default=3)
ap.add_argument("--out", default="results_c4.jsonl"); args = ap.parse_args()
gelu = lambda x: 0.5 * x * (1 + erf(x / np.sqrt(2)))
dgelu = lambda x: 0.5 * (1 + erf(x / np.sqrt(2))) + x * np.exp(-x * x / 2) / np.sqrt(2 * np.pi)
sil = lambda x: x / (1 + np.exp(-x)); sg = lambda x: 1 / (1 + np.exp(-x)); dsil = lambda x: sg(x) * (1 + x * (1 - sg(x)))
inv = lambda x: 1 / x; rsq = lambda x: 1 / np.sqrt(x)
cfg = []
for nm, f in (("1/x", inv), ("1/sqrt(x)", rsq)):
    for hi, Bc in ((10.0, 12), (100.0, 13)):
        sp = SegSpec(nm, f, 0.01, hi, 4, 10, Bc, 15, True)
        cfg.append((f"{nm} [0.01,{hi:g}] (Table 9)", 10, sp.M, sp.D, [sp.M / 2.0 ** F for F in sp.F], sp.draw_r, sp.gunit))
for hi, Bc in ((1.2 * 150, 12), (1.2 * 8192, 14)):
    sp = SegSpec("rsqrt_var", rsq, 0.01, float(hi), 4, 10, Bc, 15, True)
    cfg.append((f"rsqrt of variance [0.01,{hi:g}] (Table 6)", 15, sp.M, sp.D, [sp.M / 2.0 ** F for F in sp.F], sp.draw_r, sp.gunit))
for nm, f, d in (("GELU", gelu, dgelu), ("SiLU", sil, dsil)):
    for B in (10, 11):
        sp = TaylorSpec(nm, f, d, -20., 20., B, 22, 13)
        cfg.append((f"{nm} B={B} (Table 10)", 8, sp.D, sp.D, [sp.step], sp.draw_r, sp.gunit))
sp = TaylorSpec("exp_k", lambda z: np.exp(z / 8), None, -8., 8., 9, 15, 1, slope_ratio=1 / 8)
cfg.append(("exp, R=8 (softmax)", 18, sp.D, sp.D, [sp.step], sp.draw_r, sp.gunit))
rng = np.random.default_rng(21)
for label, depth, M, D, cells, draw_r, gunit in cfg:
    ck = Ckks(depth=depth, slots=args.slots)
    finest = float(min(cells))
    res = []
    for k in range(0, ck.L, 1):               # k = number of ciphertext-by-1.0 multiplications before masking (FLEXIBLEAUTO rescales lazily)
        worst = 0.0; ok = True
        for _ in range(args.trials):
            z = rng.uniform(0, D, args.slots)
            r_int = draw_r(rng, args.slots)
            ct = ck.enc(z)
            for _i in range(k):
                ct = ck.cc.EvalMult(ct, 1.0)
            r_low = r_int * gunit
            try:
                ct_s = ck.add_plain(ct, r_low + ck.wide_offset(rng, args.slots, M, ct))
                sv = ck.dec(ct_s, args.slots)
            except Exception as e:
                ok = False; break
            a_ = np.mod(sv, M); b_ = np.mod(z + r_low, M)
            d = np.abs(a_ - b_); d = np.minimum(d, M - d)
            worst = max(worst, float(d.max()))
        if ok and worst < M / 8:
            res.append(dict(multiplications_before_masking=k, ciphertext_level=int(ct.GetLevel()), max_error=worst, error_over_finest_cell=worst / finest))
        else:
            res.append(dict(multiplications_before_masking=k, decryption_failed=True, max_error=None if not ok else worst))
            break
    rec = dict(config=label, ckks_depth=depth, modulus_M=M, finest_cell=finest, coarsest_of_finest=float(max(cells)), slots=args.slots, trials=args.trials,
               lambda_=Ckks.LAMBDA, results_by_depth=res, hardware=dict(cores=os.cpu_count(), python=platform.python_version()), time=time.strftime("%Y-%m-%d %H:%M:%S"))
    print(json.dumps(rec), flush=True); open(args.out, "a").write(json.dumps(rec) + "\n")
    del ck
