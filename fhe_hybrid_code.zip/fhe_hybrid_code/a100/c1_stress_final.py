"""C1 / C17 (advisor): TFHE failure-rate test on the FINAL circuits of the paper (wide-mask protocol, guard cell), at scale, with every failing
element logged completely and re-run, optionally on the GPU backend, plus Concrete's own simulation mode for the same inputs.

Circuits (the exact circuit classes used by the table experiments):
  rsqrt_norm   SegMaskedLut chunk=1, 1/sqrt(x) on [0.01, 180]      (Table 6, 4 segments, Bp=10, Bc=12, Bo=15)
  inv100       SegMaskedLut,  1/x on [0.01, 100]                    (Table 9 standard configuration, Bc=13)
  gelu11       TaylorMaskedLut, GELU B=11 on [-20, 20]              (Table 10)
  exp_soft     TaylorMaskedLut, exp(z/8) slope-free B=9 on [-8, 8]  (softmax, R=8)
  old_exp8     MaskedLut of the original stress test (B=8, Bo=8, exp on [-12.8, 0]) -- the circuit of Table "stress"
Each element: random x -> exact-integer mask -> quantised index (no CKKS in the loop; this tests the TFHE circuit only, like the stress test) ->
FHE evaluation -> comparison with the exact integer circuit (same formulas as fhe_transcode/oracle.py).
A failing element is printed with ALL its inputs, re-run `--rerun` times with the same keys (is the failure deterministic?), and the result is stored.
Options: --gpu (Concrete GPU backend; requires the GPU build of concrete-python), --simulate N (circuit.simulate on N additional elements; Concrete
injects PBS errors at the compiled p_error), --p_error (default 1e-10), --seed.
Usage: python c1_stress_final.py --circuit gelu11 --elements 100000 --chunk 64 [--gpu] [--simulate 100000] --out results_c1.jsonl"""
import sys, os, json, time, math, argparse, platform
import numpy as np
from scipy.special import erf
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ap = argparse.ArgumentParser()
ap.add_argument("--circuit", required=True, choices=["rsqrt_norm", "inv100", "gelu11", "exp_soft", "old_exp8"])
ap.add_argument("--elements", type=int, default=1000); ap.add_argument("--chunk", type=int, default=16)
ap.add_argument("--gpu", action="store_true"); ap.add_argument("--simulate", type=int, default=0)
ap.add_argument("--p_error", type=float, default=1e-10); ap.add_argument("--seed", type=int, default=7)
ap.add_argument("--max_seconds", type=float, default=0, help="stop after this many seconds and record the elements actually run");ap.add_argument("--rerun", type=int, default=5); ap.add_argument("--out", default="results_c1.jsonl")
args = ap.parse_args()
kind = args.circuit
rng = np.random.default_rng(args.seed)
gelu = lambda x: 0.5 * x * (1 + erf(x / np.sqrt(2))); dgelu = lambda x: 0.5 * (1 + erf(x / np.sqrt(2))) + x * np.exp(-x * x / 2) / np.sqrt(2 * np.pi)

def words_check(expected_list, got_list):
    bad = np.zeros(len(expected_list[0][0]), bool)
    for (w_t, kp_t), (w, kp) in zip(expected_list, got_list):
        bad |= (np.asarray(w).reshape(-1) != w_t) | (np.asarray(kp).reshape(-1) != kp_t)
    return bad

if kind in ("rsqrt_norm", "inv100"):
    from fhe_transcode.seglut import SegSpec, SegMaskedLut
    if kind == "rsqrt_norm":
        spec = SegSpec("rsqrt_var", lambda x: 1 / np.sqrt(x), 0.01, 180.0, 4, 10, 12, 15, True); chunk = 1
    else:
        spec = SegSpec("1/x", lambda x: 1 / x, 0.01, 100.0, 4, 10, 13, 15, True); chunk = args.chunk
    lut = SegMaskedLut(spec, chunk=chunk, use_gpu=args.gpu, p_error=args.p_error)
    def gen(m):
        x = rng.uniform(spec.lo, spec.hi, m)
        return lut._make_inputs(x, rng)                       # (uc, us, cc, cs, r2, rho)
    def run(inp):
        uc, us, cc, cs, r2, rho = inp
        w, kp = lut.client_decrypt(lut.server_run(*lut.client_encrypt(uc, us), cc, cs, r2, rho))
        return [(w, kp)]
    def expect(inp):
        uc, us, cc, cs, r2, rho = inp
        y1 = spec.reference_y1(np.asarray(uc, np.int64), np.asarray(us, np.int64), np.asarray(cc, np.int64), np.asarray(cs, np.int64))
        s = y1 + r2; M = 1 << spec.Bo
        return [(s % M, (s >= M).astype(np.int64) ^ rho)]
    def sim(inp):
        uc, us, cc, cs, r2, rho = inp
        out = lut.circuit.simulate(*lut._flat(inp))
        return [(np.asarray(out[0]), np.asarray(out[1]))]
    def describe(inp, i):
        uc, us, cc, cs, r2, rho = inp
        return dict(uc=int(np.ravel(uc)[i]), us=[int(np.ravel(v)[i]) for v in us], cc=int(np.ravel(cc)[i]), cs=[int(np.ravel(v)[i]) for v in cs], r2=int(np.ravel(r2)[i]), rho=int(np.ravel(rho)[i]))
    pbs = int(lut.circuit.programmable_bootstrap_count) // chunk
elif kind in ("gelu11", "exp_soft"):
    from fhe_transcode.taylor import TaylorSpec, TaylorMaskedLut
    spec = TaylorSpec("GELU", gelu, dgelu, -20., 20., 11, 22, 13) if kind == "gelu11" else TaylorSpec("exp_k", lambda z: np.exp(z / 8), None, -8., 8., 9, 15, 1, slope_ratio=1 / 8)
    chunk = args.chunk
    lut = TaylorMaskedLut(spec, chunk=chunk, use_gpu=args.gpu, p_error=args.p_error)
    nw = len(spec.words())
    def gen(m):
        x = rng.uniform(spec.lo, spec.hi, m)
        r_int = spec.draw_r(rng, m)
        z = np.clip(x - spec.lo, 0, spec.D - spec.step * 1e-9)
        u = spec.client_quantise(z + r_int * spec.gunit)
        c = spec.server_consts(r_int)
        r2 = np.stack([rng.integers(0, 1 << b, m) for (_, _, b) in spec.words()]); rho = rng.integers(0, 2, (nw, m))
        return (u, c, r2, rho)
    def run(inp):
        u, c, r2, rho = inp
        return lut.client_decrypt(lut.server_run(lut.client_encrypt(u), c, r2, rho))
    def expect(inp):
        u, c, r2, rho = inp
        res = spec.res_of(u, c); out = []
        for j, (_, tab, b) in enumerate(spec.words()):
            s = np.asarray(tab)[res] + r2[j]; M = 1 << b
            out.append((s % M, (s >= M).astype(np.int64) ^ rho[j]))
        return out
    def sim(inp):
        u, c, r2, rho = inp
        out = lut.circuit.simulate(u, c, *list(r2), *list(rho))
        return [(np.asarray(out[2 * j]), np.asarray(out[2 * j + 1])) for j in range(nw)]
    def describe(inp, i):
        u, c, r2, rho = inp
        return dict(u=int(u[i]), c=int(c[i]), r2=[int(v[i]) for v in r2], rho=[int(v[i]) for v in rho])
    pbs = int(lut.circuit.programmable_bootstrap_count) // chunk
else:   # old_exp8: the circuit of the original stress test
    from fhe_transcode.tfhe_ops import LutSpec, MaskedLut
    B = Bo = 8; chunk = args.chunk
    spec = LutSpec("exp", np.exp, lo=-12.8, hi=0.0, B=B, out_scale=float(2 ** Bo - 1), Bo=Bo, chunk=chunk)
    lut = MaskedLut(spec, use_gpu=args.gpu, p_error=args.p_error, strategy="mono")
    N = 1 << B
    def gen(m):
        x = rng.uniform(-12.7, -0.01, m); xq = spec.quant(x); rq = rng.integers(0, N, m)
        return ((xq + rq) % N, N - rq, rng.integers(0, 1 << Bo, m), rng.integers(0, 2, m), xq)
    def run(inp):
        u, c, r2, rho, xq = inp
        w, kp = lut.client_decrypt(lut.server_run(lut.client_encrypt(u), c, r2, rho)); return [(w, kp)]
    def expect(inp):
        u, c, r2, rho, xq = inp
        s = spec.table()[xq] + r2; return [(s % (1 << Bo), (s >= (1 << Bo)).astype(np.int64) ^ rho)]
    def sim(inp):
        u, c, r2, rho, xq = inp
        out = lut.circuit.simulate(u, c, r2, rho); return [(np.asarray(out[0]), np.asarray(out[1]))]
    def describe(inp, i):
        u, c, r2, rho, xq = inp
        return dict(u=int(u[i]), c=int(c[i]), r2=int(r2[i]), rho=int(rho[i]), xq=int(xq[i]))
    pbs = int(lut.circuit.programmable_bootstrap_count) // chunk

print(f"circuit {kind}: chunk {chunk}, PBS/element {pbs}, reported p_error {lut.circuit.p_error:.3g}, global_p_error {lut.circuit.global_p_error:.3g}, keygen {lut.t_keygen:.1f}s", flush=True)
t0 = time.time(); last_print = t0; total = bad_total = 0; failures = []
nchunks = max(1, args.elements // chunk)
for ch in range(nchunks):
    if args.max_seconds and time.time() - t0 > args.max_seconds:
        print(f"time budget reached after {total} elements", flush=True); break
    inp = gen(chunk)
    got = run(inp); exp_ = expect(inp)
    bad = words_check(exp_, got)
    total += len(bad); bad_total += int(bad.sum())
    for i in np.where(bad)[0]:
        d = describe(inp, int(i)); d["chunk_index"] = ch; d["element_in_chunk"] = int(i)
        d["got"] = [[int(np.ravel(w)[i]), int(np.ravel(k)[i])] for (w, k) in got]; d["expected"] = [[int(w[i]), int(k[i])] for (w, k) in exp_]
        reruns = []
        for _ in range(args.rerun):                           # same inputs, same keys
            g2 = run(inp); reruns.append(bool(words_check(exp_, g2)[i]))
        d["rerun_failed"] = reruns
        failures.append(d); print("FAIL", json.dumps(d), flush=True)
    if (ch + 1) % max(1, nchunks // 20) == 0 or time.time() - last_print > 120:
        last_print = time.time()
        print(f"  {total} elements, {bad_total} bad, {time.time()-t0:.0f}s", flush=True)
        open(args.out + ".partial", "w").write(json.dumps(dict(circuit=kind, elements=total, bad=bad_total, failures=failures, time_s=time.time() - t0)) + "\n")
rec = dict(circuit=kind, elements=total, bad=bad_total, chunk=chunk, pbs_per_element=pbs, p_error_target=args.p_error, p_error_reported=lut.circuit.p_error,
           global_p_error=lut.circuit.global_p_error, gpu=args.gpu, seed=args.seed, time_s=time.time() - t0, failures=failures,
           hardware=dict(cores=os.cpu_count(), python=platform.python_version()), time=time.strftime("%Y-%m-%d %H:%M:%S"))
if args.simulate:
    sb = st = 0
    for ch in range(max(1, args.simulate // chunk)):
        inp = gen(chunk); got = sim(inp); exp_ = expect(inp)
        b = words_check(exp_, got); st += len(b); sb += int(b.sum())
    rec["simulation"] = dict(elements=st, bad=sb, note="Concrete circuit.simulate: PBS errors injected at the compiled p_error")
print("RESULT", json.dumps({k: v for k, v in rec.items() if k != "failures"}), flush=True)
open(args.out, "a").write(json.dumps(rec) + "\n")
